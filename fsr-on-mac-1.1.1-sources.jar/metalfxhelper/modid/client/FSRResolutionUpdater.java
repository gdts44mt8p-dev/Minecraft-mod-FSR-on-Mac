package metalfxhelper.modid.client;

import com.mojang.blaze3d.platform.Window;
import java.lang.reflect.Method;

/**
 * FSR 分辨率更新辅助类
 * 使用反射调用 Window mixin 上的方法，避免直接引用 Mixin 类
 */
public class FSRResolutionUpdater {

    private static final String UPDATE_METHOD = "metalfxhelper$updateFSRResolution";

    /**
     * 更新 Window 的 FSR 分辨率
     *
     * @param window Window 实例
     * @param width  FSR 逻辑渲染宽度
     * @param height FSR 逻辑渲染高度
     * @param active FSR 是否激活
     */
    public static void updateFSRResolution(Window window, int width, int height, boolean active) {
        try {
            Method method = Window.class.getDeclaredMethod(UPDATE_METHOD, int.class, int.class, boolean.class);
            method.invoke(window, width, height, active);
        } catch (NoSuchMethodException e) {
            // Mixin 方法不存在，说明 mixin 没有应用成功
            System.err.println("[FSRResolutionUpdater] Mixin method not found: " + UPDATE_METHOD);
            System.err.println("[FSRResolutionUpdater] Window class methods:");
            for (Method m : Window.class.getDeclaredMethods()) {
                if (m.getName().contains("metalfxhelper")) {
                    System.err.println("  - " + m.getName());
                }
            }
            throw new RuntimeException("WindowFSRMixin not applied correctly", e);
        } catch (Exception e) {
            System.err.println("[FSRResolutionUpdater] Failed to update FSR resolution: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Failed to update FSR resolution", e);
        }
    }
}
