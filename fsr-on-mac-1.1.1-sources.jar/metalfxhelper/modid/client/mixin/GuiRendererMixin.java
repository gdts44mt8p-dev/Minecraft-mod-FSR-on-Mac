package metalfxhelper.modid.client.mixin;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.platform.Window;
import com.mojang.blaze3d.systems.RenderPass;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.client.gui.render.GuiRenderer;
import net.minecraft.client.renderer.Projection;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * GUI 渲染修复 Mixin（FSR 低分辨率渲染下的 GUI 放大问题）
 *
 * 背景：WindowFSRMixin 把 Window.getWidth()/getHeight() 改为 FSR 低分辨率（如 596×336），
 * GameRenderer.extractWindow() 将其写入 WindowRenderState（wrs）。3D 渲染链路全部自洽，
 * 但 GuiRenderer 有两处用 wrs 反推 GUI 逻辑尺寸，与基于物理分辨率的 GUI 布局空间
 * （getGuiScaledWidth/Height ≈ 854×480）不一致：
 *
 *   1. draw() 的正交投影用 wrs.width/guiScale（596/2=298×168）→ GUI 元素在
 *      mainRenderTarget 内被画成 2 倍大、只显示左上角 35%，上屏拉伸后再放大
 *      2.87 倍 → 巨型 GUI + 右/下裁切；
 *   2. enableScissor() 把逻辑坐标 ×guiScale（物理像素空间）却用 wrs.width/height
 *      （低分辨率 target 像素空间）截断/Y 翻转 → 裁剪区域错误。
 *
 * 两个修复在 vanilla（无 FSR）下与原版行为严格等价：
 *   - getGuiScaledWidth() == framebufferWidth/guiScale（ceil，偶数宽度时完全相等）；
 *   - target.width/guiScaledWidth == guiScale（1708/854 = 2.0）。
 */
@Mixin(GuiRenderer.class)
public abstract class GuiRendererMixin {

    /**
     * 修正 GUI 正交投影的逻辑尺寸：用未被污染的 getGuiScaledWidth/Height
     * 替换 wrs.width/guiScale、wrs.height/guiScale。
     */
    @Redirect(
        method = "draw()V",
        at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/Projection;setupOrtho(FFFFZ)V")
    )
    private void metalfxhelper$fixGuiOrtho(Projection projection, float zNear, float zFar,
                                           float width, float height, boolean invertY) {
        Window window = Minecraft.getInstance().getWindow();
        projection.setupOrtho(
                zNear, zFar,
                (float) window.getGuiScaledWidth(),
                (float) window.getGuiScaledHeight(),
                invertY
        );
    }

    /**
     * 修正 GUI 剪刀矩形：倍率改为 target/guiScaled（vanilla 下恒等于 guiScale），
     * 截断与 Y 翻转基准改为 mainRenderTarget 实际尺寸。
     */
    @Inject(
        method = "enableScissor(Lnet/minecraft/client/gui/navigation/ScreenRectangle;Lcom/mojang/blaze3d/systems/RenderPass;)V",
        at = @At("HEAD"),
        cancellable = true
    )
    private void metalfxhelper$fixScissor(ScreenRectangle rect, RenderPass pass, CallbackInfo ci) {
        ci.cancel();

        Minecraft mc = Minecraft.getInstance();
        Window window = mc.getWindow();
        RenderTarget target = mc.gameRenderer.mainRenderTarget();

        float scaleX = target.width / (float) window.getGuiScaledWidth();
        float scaleY = target.height / (float) window.getGuiScaledHeight();

        int x0 = (int) (rect.left() * scaleX);
        int y0 = (int) (rect.top() * scaleY);
        int x1 = Math.min((int) (rect.right() * scaleX), target.width);
        int y1 = Math.min((int) (rect.bottom() * scaleY), target.height);

        pass.enableScissor(
                x0,
                target.height - y1,
                Math.max(0, x1 - x0),
                Math.max(0, y1 - y0)
        );
    }
}
