package metalfxhelper.modid.client.mixin;

import com.mojang.blaze3d.vulkan.VulkanGpuSurface;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Accessor for VulkanGpuSurface to access swapchain dimensions
 */
@Mixin(VulkanGpuSurface.class)
public interface VulkanGpuSurfaceAccessor {

    @Accessor("swapchainWidth")
    int metalfxhelper$getSwapchainWidth();

    @Accessor("swapchainHeight")
    int metalfxhelper$getSwapchainHeight();
}
