package metalfxhelper.modid.client.mixin;

import metalfxhelper.modid.client.FSR1Manager;
import metalfxhelper.modid.client.FSR1Preset;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.state.WindowRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

/**
 * FSR 1.0 GameRenderer Mixin - 修改 extractWindow 中的 WindowRenderState 尺寸
 *
 * 当 FSR 启用时，让 WindowRenderState 以 FSR 低分辨率渲染，
 * 这样 mainRenderTarget 也会以 FSR 尺寸 resize，
 * 3D 渲染负载会降低，实现真正的 FSR 性能提升。
 *
 * 注意：这会导致 GUI 也在 FSR 尺寸下渲染，可能略显模糊，
 * 但这是实现 FSR 性能提升的必要代价。
 */
@Mixin(GameRenderer.class)
public class GameRendererFSRMixin {

    // 记录上次修改的尺寸，避免重复日志
    @Unique
    private static int metalfxhelper$lastFSRWidth = 0;

    @Unique
    private static int metalfxhelper$lastFSRHeight = 0;

    /**
     * 在 extractWindow 方法返回前修改 WindowRenderState 的 width 和 height
     */
    @Inject(
        method = "extractWindow",
        at = @At("RETURN"),
        locals = LocalCapture.CAPTURE_FAILHARD
    )
    private void onExtractWindowReturn(CallbackInfo ci, WindowRenderState windowRenderState) {
        FSR1Preset preset = FSR1Manager.INSTANCE.getCurrentPreset();

        // 只在 FSR 启用且不是超分档/关闭档时修改分辨率
        if (preset == FSR1Preset.OFF || preset == FSR1Preset.UPSCALED) {
            // 重置记录
            metalfxhelper$lastFSRWidth = 0;
            metalfxhelper$lastFSRHeight = 0;
            return;
        }

        int originalWidth = windowRenderState.width;
        int originalHeight = windowRenderState.height;
        float scale = preset.getRenderScale();

        // 计算 FSR 渲染分辨率
        int fsrWidth = Math.max(2, (int)(originalWidth * scale) & ~1);
        int fsrHeight = Math.max(2, (int)(originalHeight * scale) & ~1);

        // 确保不低于最小值
        fsrWidth = Math.max(fsrWidth, 320);
        fsrHeight = Math.max(fsrHeight, 240);

        // 只在尺寸变化时打印日志
        if (fsrWidth != metalfxhelper$lastFSRWidth || fsrHeight != metalfxhelper$lastFSRHeight) {
            System.out.println("[GameRendererFSRMixin] WindowRenderState: " +
                originalWidth + "x" + originalHeight + " -> " + fsrWidth + "x" + fsrHeight +
                " (" + preset.getDisplayName() + ")");
            metalfxhelper$lastFSRWidth = fsrWidth;
            metalfxhelper$lastFSRHeight = fsrHeight;
        }

        // 修改 WindowRenderState 的尺寸
        windowRenderState.width = fsrWidth;
        windowRenderState.height = fsrHeight;
    }
}
