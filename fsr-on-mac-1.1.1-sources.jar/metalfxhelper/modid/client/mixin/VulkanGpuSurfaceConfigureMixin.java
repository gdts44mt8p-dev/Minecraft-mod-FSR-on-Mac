package metalfxhelper.modid.client.mixin;

import com.mojang.blaze3d.systems.GpuSurface;
import com.mojang.blaze3d.vulkan.VulkanGpuSurface;
import metalfxhelper.modid.client.FSR1Manager;
import metalfxhelper.modid.client.FSR1Preset;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * 修改 Vulkan swapchain 创建尺寸为 FSR 低分辨率
 *
 * 当 FSR 启用时，将 swapchain 尺寸缩小为 FSR 输入分辨率，
 * 这样 Minecraft 就会以更低分辨率渲染，减少 GPU 负载。
 */
@Mixin(VulkanGpuSurface.class)
public class VulkanGpuSurfaceConfigureMixin {

    // 记录上次修改的配置，避免重复修改
    @Unique
    private static int metalfxhelper$lastModifiedWidth = 0;

    @Unique
    private static int metalfxhelper$lastModifiedHeight = 0;

    /**
     * 修改 configure 方法的 Configuration 参数，降低 swapchain 分辨率
     */
    @ModifyVariable(
        method = "configure(Lcom/mojang/blaze3d/systems/GpuSurface$Configuration;)V",
        at = @At("HEAD")
    )
    private GpuSurface.Configuration modifyConfiguration(GpuSurface.Configuration config) {
        FSR1Preset preset = FSR1Manager.INSTANCE.getCurrentPreset();

        // 只在 FSR 启用且不是超分档/关闭档时修改分辨率
        if (preset == FSR1Preset.OFF || preset == FSR1Preset.UPSCALED) {
            return config;
        }

        int originalWidth = config.width();
        int originalHeight = config.height();
        float scale = preset.getRenderScale();

        // 保存原始分辨率（用于后续计算渲染节省）
        FSR1Manager.INSTANCE.setOriginalResolution(originalWidth, originalHeight);

        // 计算 FSR 输入分辨率（向下取整到偶数，避免 Vulkan 问题）
        int fsrWidth = Math.max(2, (int)(originalWidth * scale) & ~1);
        int fsrHeight = Math.max(2, (int)(originalHeight * scale) & ~1);

        // 确保不低于最小值
        fsrWidth = Math.max(fsrWidth, 320);
        fsrHeight = Math.max(fsrHeight, 240);

        // 只在配置真正变化时打印日志
        if (fsrWidth != metalfxhelper$lastModifiedWidth || fsrHeight != metalfxhelper$lastModifiedHeight) {
            System.out.println("[FSR Configure] 修改渲染分辨率: " + originalWidth + "x" + originalHeight +
                              " -> " + fsrWidth + "x" + fsrHeight +
                              " (" + preset.getDisplayName() + ", scale=" + scale + ")");
            metalfxhelper$lastModifiedWidth = fsrWidth;
            metalfxhelper$lastModifiedHeight = fsrHeight;
        }

        // 创建新的 Configuration 对象（Java Record）
        return new GpuSurface.Configuration(fsrWidth, fsrHeight, config.presentMode());
    }
}
