package metalfxhelper.modid.client.mixin;

import net.minecraft.client.gui.screens.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(TitleScreen.class)
public abstract class ExampleClientMixin {

	@Inject(method = "init", at = @At("HEAD"))
	private void onInit(CallbackInfo ci) {
		System.out.println("✅ Mixin 注入成功：你已进入标题界面！");
	}
}