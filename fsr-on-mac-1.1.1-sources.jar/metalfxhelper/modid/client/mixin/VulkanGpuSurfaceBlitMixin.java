package metalfxhelper.modid.client.mixin;

import com.mojang.blaze3d.systems.CommandEncoderBackend;
import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vulkan.VulkanCommandEncoder;
import com.mojang.blaze3d.vulkan.VulkanDevice;
import com.mojang.blaze3d.vulkan.VulkanGpuSurface;
import com.mojang.blaze3d.vulkan.VulkanGpuTexture;
import it.unimi.dsi.fastutil.longs.LongList;
import metalfxhelper.modid.client.FSR1Manager;
import metalfxhelper.modid.client.fsr.FSR1Vulkan;
import metalfxhelper.modid.client.fsr.FSR1VulkanManager;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.KHRSwapchain;
import org.lwjgl.vulkan.KHRSynchronization2;
import org.lwjgl.vulkan.VK12;
import org.lwjgl.vulkan.VkCommandBuffer;
import org.lwjgl.vulkan.VkDependencyInfo;
import org.lwjgl.vulkan.VkImageBlit;
import org.lwjgl.vulkan.VkImageMemoryBarrier2;
import org.lwjgl.vulkan.VkImageSubresourceLayers;
import org.lwjgl.vulkan.VkMemoryBarrier2;
import org.lwjgl.vulkan.VkOffset3D;
import org.lwjgl.vulkan.VkPhysicalDevice;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static org.lwjgl.vulkan.VK10.*;

/**
 * FSR 拉伸 Blit Mixin
 *
 * 背景：MC 26.2 的 {@code VulkanGpuSurface.blitFromTexture} 是 1:1 像素拷贝
 * （min 裁剪 + Y 翻转），不做任何缩放。FSR 低分辨率渲染时 mainRenderTarget
 * 只有 swapchain 的一小部分，原版 blit 只写 swapchain image 左上角区域，
 * 其余区域内容 undefined → 高频闪烁。
 *
 * 本 Mixin 在源纹理小于 swapchain（即 FSR 低分辨率渲染）时接管 blit，两级路径：
 *   1. JNI FSR compute（优先）：EASU+RCAS 超分到 mod 自有的全分辨率离屏纹理
 *      （usage = STORAGE | TRANSFER_SRC），再用与原版逐字节一致的 transfer blit
 *      （含 Y 翻转）拷入 swapchain；
 *   2. LINEAR 拉伸 blit（回退）：JNI 上下文不可用时的保底方案。
 *
 * 为什么不直写 swapchain（v1.1.0 修复）：
 *   - swapchain image usage 只有 TRANSFER_DST，当 storage 写是 usage 违规；
 *   - compute 写入与 present semaphore 的 TRANSFER signal 阶段不匹配 → 竞争黑屏；
 *   - EASU 无 Y 翻转 → 画面倒置。
 *
 * 布局事实（已由字节码核实）：MC 26.2 的渲染目标纹理常驻 VK_IMAGE_LAYOUT_GENERAL
 * （原版 blitFromTexture 的 srcLayout 参数即为 GENERAL），JNI dispatch 的 src 无需迁移。
 * 离屏纹理每帧流转：GENERAL（dispatch 写）→ TRANSFER_SRC_OPTIMAL（blit 读）→ GENERAL。
 */
@Mixin(VulkanGpuSurface.class)
public abstract class VulkanGpuSurfaceBlitMixin {

    @Shadow private boolean swapchainOutOfDate;
    @Shadow private int currentImageIndex;
    @Shadow private LongList swapchainImages;
    @Shadow private int swapchainWidth;
    @Shadow private int swapchainHeight;
    @Shadow private int swapchainImageFormat;
    @Shadow private VulkanDevice device;
    @Shadow @Final private long[] acquireSemaphores;
    @Shadow private int currentAcquireSemaphore;
    @Shadow private long[] presentSemaphores;

    /** 上次记录日志时的源尺寸（避免每帧刷屏） */
    @Unique private int metalfxhelper$lastLoggedSrcW = -1;
    @Unique private int metalfxhelper$lastLoggedSrcH = -1;

    /** JNI 路径状态：是否已尝试初始化 / 是否已失败（失败后永久回退 LINEAR） */
    @Unique private boolean metalfxhelper$nativeInitAttempted = false;
    @Unique private boolean metalfxhelper$nativeFailed = false;
    @Unique private boolean metalfxhelper$nativeLogged = false;

    @Inject(method = "blitFromTexture", at = @At("HEAD"), cancellable = true)
    private void metalfxhelper$stretchBlit(CommandEncoderBackend encoderBackend, GpuTextureView textureView, CallbackInfo ci) {
        if (currentImageIndex < 0) {
            return; // 未 acquire，交给原版处理（开发环境会触发其 assert）
        }

        int srcW = textureView.getWidth(0);
        int srcH = textureView.getHeight(0);

        // 仅当源纹理小于 swapchain（即 FSR 低分辨率渲染）时才接管；
        // 同尺寸（FSR 关闭 / UPSCALED 档）走原版 1:1 路径，行为与无 mod 完全一致。
        if (srcW >= swapchainWidth && srcH >= swapchainHeight) {
            return;
        }

        ci.cancel();

        // 懒初始化 JNI FSR 上下文（只尝试一次；失败则永久回退 LINEAR）
        FSR1VulkanManager vm = FSR1VulkanManager.getInstance();
        if (!vm.isReady() && !metalfxhelper$nativeInitAttempted) {
            metalfxhelper$nativeInitAttempted = true;
            metalfxhelper$tryInitNative(vm);
        }

        if (vm.isReady() && !metalfxhelper$nativeFailed) {
            metalfxhelper$blitNative(encoderBackend, textureView, srcW, srcH, vm);
        } else {
            metalfxhelper$blitStretched(encoderBackend, textureView, srcW, srcH);
        }
    }

    /**
     * 用真实 swapchain 格式初始化 JNI FSR 上下文。
     */
    @Unique
    private void metalfxhelper$tryInitNative(FSR1VulkanManager vm) {
        try {
            GpuDevice gpuDevice = RenderSystem.getDevice();
            VkPhysicalDevice physicalDevice = FSR1Manager.INSTANCE.getPhysicalDevice();
            if (gpuDevice == null || physicalDevice == null) {
                System.out.println("[FSR Blit] ⚠️ JNI 初始化条件不足（device/physicalDevice 为空），使用 LINEAR 拉伸");
                return;
            }
            vm.initialize(gpuDevice, physicalDevice, swapchainImageFormat);
            if (vm.isReady()) {
                System.out.println("[FSR Blit] JNI FSR 上下文就绪，输出格式 = " + swapchainImageFormat);
            }
        } catch (Exception e) {
            System.out.println("[FSR Blit] ❌ JNI 初始化异常: " + e.getMessage() + "，使用 LINEAR 拉伸");
            e.printStackTrace();
        }
    }

    /**
     * 路径 1（优先）：JNI FSR EASU+RCAS compute → 离屏纹理 → Y 翻转 blit → swapchain。
     *
     * swapchain 侧的 barrier / blit / semaphore 与原版 blitFromTexture 逐字节一致；
     * compute 只接触 mod 自有的离屏纹理，互不干扰。
     */
    @Unique
    private void metalfxhelper$blitNative(CommandEncoderBackend encoderBackend, GpuTextureView textureView,
                                          int srcW, int srcH, FSR1VulkanManager vm) {
        if (swapchainOutOfDate) {
            throw new IllegalStateException("Attempt to use out of date swapchain");
        }

        // 确保离屏纹理存在（尺寸 = swapchain 物理尺寸）
        int offscreenState = vm.ensureOffscreen(swapchainWidth, swapchainHeight, swapchainImageFormat);
        if (offscreenState < 0) {
            System.out.println("[FSR Blit] ❌ 离屏纹理创建失败，回退 LINEAR 拉伸");
            metalfxhelper$nativeFailed = true;
            metalfxhelper$blitStretched(encoderBackend, textureView, srcW, srcH);
            return;
        }

        VulkanCommandEncoder encoder = (VulkanCommandEncoder) encoderBackend;
        VkCommandBuffer cmdBuf = encoder.allocateAndBeginTransientCommandBuffer();
        long swapchainImage = swapchainImages.getLong(currentImageIndex);
        long offscreenImage = vm.getOffscreenImage();
        MemoryStack stack = MemoryStack.stackGet();

        // ---- 0. 离屏纹理新建后：UNDEFINED -> GENERAL（仅一次） ----
        if (offscreenState == 1) {
            metalfxhelper$imageBarrier(cmdBuf, stack, offscreenImage,
                    0, 0,
                    VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT, VK_ACCESS_SHADER_WRITE_BIT,
                    VK_IMAGE_LAYOUT_UNDEFINED, VK_IMAGE_LAYOUT_GENERAL);
        }

        // ---- 1. JNI dispatch：EASU+RCAS，低分辨率 src(GENERAL) -> 离屏(GENERAL) ----
        int result = vm.dispatchToOffscreen(textureView, srcW, srcH,
                swapchainWidth, swapchainHeight, cmdBuf.address());

        if (result != FSR1Vulkan.OK) {
            System.out.println("[FSR Blit] ❌ JNI dispatch 失败 (code=" + result + ")，后续帧回退 LINEAR 拉伸");
            metalfxhelper$nativeFailed = true;
        } else if (!metalfxhelper$nativeLogged) {
            metalfxhelper$nativeLogged = true;
            System.out.println("[FSR Blit] ✅ JNI EASU+RCAS dispatch 启用: " + srcW + "x" + srcH +
                " -> " + swapchainWidth + "x" + swapchainHeight + " (离屏 + Y翻转 blit)");
        }

        // ---- 2. 离屏 GENERAL -> TRANSFER_SRC_OPTIMAL（供 blit 读取） ----
        metalfxhelper$imageBarrier(cmdBuf, stack, offscreenImage,
                VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT, VK_ACCESS_SHADER_WRITE_BIT,
                VK_PIPELINE_STAGE_TRANSFER_BIT, VK_ACCESS_TRANSFER_READ_BIT,
                VK_IMAGE_LAYOUT_GENERAL, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL);

        // ---- 3. swapchain image UNDEFINED -> TRANSFER_DST_OPTIMAL（与原版一致） ----
        metalfxhelper$imageBarrier(cmdBuf, stack, swapchainImage,
                0, 0,
                VK_PIPELINE_STAGE_TRANSFER_BIT, VK_ACCESS_TRANSFER_WRITE_BIT,
                VK_IMAGE_LAYOUT_UNDEFINED, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL);

        // ---- 4. Y 翻转 blit：离屏全幅 -> swapchain 全幅（与原版相同的翻转，1:1 NEAREST） ----
        try (MemoryStack ignored = stack.push()) {
            VkOffset3D.Buffer srcOffsets = VkOffset3D.calloc(2, stack);
            srcOffsets.x(0).y(0).z(0);
            srcOffsets.position(1);
            srcOffsets.x(swapchainWidth).y(swapchainHeight).z(1);
            srcOffsets.position(0);

            VkOffset3D.Buffer dstOffsets = VkOffset3D.calloc(2, stack);
            dstOffsets.x(0).y(swapchainHeight).z(0);
            dstOffsets.position(1);
            dstOffsets.x(swapchainWidth).y(0).z(1);
            dstOffsets.position(0);

            VkImageSubresourceLayers srcLayers = VkImageSubresourceLayers.calloc(stack)
                    .aspectMask(VK_IMAGE_ASPECT_COLOR_BIT)
                    .mipLevel(0)
                    .baseArrayLayer(0)
                    .layerCount(1);
            VkImageSubresourceLayers dstLayers = VkImageSubresourceLayers.calloc(stack)
                    .aspectMask(VK_IMAGE_ASPECT_COLOR_BIT)
                    .mipLevel(0)
                    .baseArrayLayer(0)
                    .layerCount(1);

            VkImageBlit.Buffer region = VkImageBlit.calloc(1, stack);
            region.srcSubresource(srcLayers);
            region.srcOffsets(srcOffsets);
            region.dstSubresource(dstLayers);
            region.dstOffsets(dstOffsets);

            VK12.vkCmdBlitImage(
                    cmdBuf,
                    offscreenImage, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,
                    swapchainImage, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
                    region,
                    VK_FILTER_NEAREST
            );
        }

        // ---- 5. swapchain TRANSFER_DST_OPTIMAL -> PRESENT_SRC_KHR（与原版一致） ----
        try (MemoryStack ignored = stack.push()) {
            VkImageMemoryBarrier2.Buffer imgBarrier = VkImageMemoryBarrier2.calloc(1, stack).sType$Default();
            imgBarrier.srcStageMask(VK_PIPELINE_STAGE_TRANSFER_BIT);
            imgBarrier.srcAccessMask(VK_ACCESS_TRANSFER_WRITE_BIT);
            imgBarrier.dstStageMask(VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT);
            imgBarrier.dstAccessMask(0);
            imgBarrier.oldLayout(VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL);
            imgBarrier.newLayout(KHRSwapchain.VK_IMAGE_LAYOUT_PRESENT_SRC_KHR);
            imgBarrier.srcQueueFamilyIndex(-1);
            imgBarrier.dstQueueFamilyIndex(-1);
            imgBarrier.image(swapchainImage);
            imgBarrier.subresourceRange()
                    .aspectMask(VK_IMAGE_ASPECT_COLOR_BIT)
                    .baseMipLevel(0)
                    .levelCount(1)
                    .baseArrayLayer(0)
                    .layerCount(1);

            VkMemoryBarrier2.Buffer memBarrier = VkMemoryBarrier2.calloc(1, stack).sType$Default();
            memBarrier.srcStageMask(VK_PIPELINE_STAGE_TRANSFER_BIT);
            memBarrier.srcAccessMask(VK_ACCESS_TRANSFER_READ_BIT);
            memBarrier.dstStageMask(VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT);
            memBarrier.dstAccessMask(VK_ACCESS_MEMORY_READ_BIT | VK_ACCESS_MEMORY_WRITE_BIT);

            VkDependencyInfo dependencyInfo = VkDependencyInfo.calloc(stack).sType$Default();
            dependencyInfo.pMemoryBarriers(memBarrier);
            dependencyInfo.pImageMemoryBarriers(imgBarrier);
            KHRSynchronization2.vkCmdPipelineBarrier2KHR(cmdBuf, dependencyInfo);
        }

        // ---- 6. 离屏 TRANSFER_SRC_OPTIMAL -> GENERAL（供下一帧 dispatch） ----
        metalfxhelper$imageBarrier(cmdBuf, stack, offscreenImage,
                VK_PIPELINE_STAGE_TRANSFER_BIT, VK_ACCESS_TRANSFER_READ_BIT,
                VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT, VK_ACCESS_SHADER_WRITE_BIT,
                VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, VK_IMAGE_LAYOUT_GENERAL);

        // ---- 提交并与 acquire/present semaphore 挂接（与原版一致，TRANSFER 阶段） ----
        metalfxhelper$submit(encoder, cmdBuf);
    }

    /**
     * 路径 2（回退）：双线性拉伸 blit。同步流程与原版 blitFromTexture 一致，
     * 仅 dstOffsets 为 swapchain 全幅、filter 为 VK_FILTER_LINEAR。
     */
    @Unique
    private void metalfxhelper$blitStretched(CommandEncoderBackend encoderBackend, GpuTextureView textureView, int srcW, int srcH) {
        if (swapchainOutOfDate) {
            throw new IllegalStateException("Attempt to use out of date swapchain");
        }

        if (srcW != metalfxhelper$lastLoggedSrcW || srcH != metalfxhelper$lastLoggedSrcH) {
            System.out.println("[FSR Blit] LINEAR 拉伸模式: " + srcW + "x" + srcH +
                " -> " + swapchainWidth + "x" + swapchainHeight);
            metalfxhelper$lastLoggedSrcW = srcW;
            metalfxhelper$lastLoggedSrcH = srcH;
        }

        VulkanCommandEncoder encoder = (VulkanCommandEncoder) encoderBackend;
        VkCommandBuffer cmdBuf = encoder.allocateAndBeginTransientCommandBuffer();
        long swapchainImage = swapchainImages.getLong(currentImageIndex);
        MemoryStack stack = MemoryStack.stackGet();

        // ---- Barrier 1: swapchain image UNDEFINED -> TRANSFER_DST_OPTIMAL ----
        metalfxhelper$imageBarrier(cmdBuf, stack, swapchainImage,
                0, 0,
                VK_PIPELINE_STAGE_TRANSFER_BIT, VK_ACCESS_TRANSFER_WRITE_BIT,
                VK_IMAGE_LAYOUT_UNDEFINED, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL);

        // ---- 拉伸 Blit：src = 源纹理全幅，dst = swapchain 全幅（Y 翻转），LINEAR 过滤 ----
        try (MemoryStack ignored = stack.push()) {
            VkOffset3D.Buffer srcOffsets = VkOffset3D.calloc(2, stack);
            srcOffsets.x(0).y(0).z(0);
            srcOffsets.position(1);
            srcOffsets.x(srcW).y(srcH).z(1);
            srcOffsets.position(0);

            VkOffset3D.Buffer dstOffsets = VkOffset3D.calloc(2, stack);
            dstOffsets.x(0).y(swapchainHeight).z(0);
            dstOffsets.position(1);
            dstOffsets.x(swapchainWidth).y(0).z(1);
            dstOffsets.position(0);

            VkImageSubresourceLayers srcLayers = VkImageSubresourceLayers.calloc(stack)
                    .aspectMask(VK_IMAGE_ASPECT_COLOR_BIT)
                    .mipLevel(textureView.baseMipLevel())
                    .baseArrayLayer(0)
                    .layerCount(1);
            VkImageSubresourceLayers dstLayers = VkImageSubresourceLayers.calloc(stack)
                    .aspectMask(VK_IMAGE_ASPECT_COLOR_BIT)
                    .mipLevel(0)
                    .baseArrayLayer(0)
                    .layerCount(1);

            VkImageBlit.Buffer region = VkImageBlit.calloc(1, stack);
            region.srcSubresource(srcLayers);
            region.srcOffsets(srcOffsets);
            region.dstSubresource(dstLayers);
            region.dstOffsets(dstOffsets);

            // 注意：MC 26.2 的渲染目标纹理常驻 GENERAL layout（原版 blit 的 srcLayout
            // 参数即为 GENERAL），此处必须与其实际布局一致，不能用 TRANSFER_SRC_OPTIMAL
            VK12.vkCmdBlitImage(
                    cmdBuf,
                    ((VulkanGpuTexture) textureView.texture()).vkImage(), VK_IMAGE_LAYOUT_GENERAL,
                    swapchainImage, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
                    region,
                    VK_FILTER_LINEAR
            );
        }

        // ---- Barrier 2: TRANSFER_DST_OPTIMAL -> PRESENT_SRC_KHR（与原版一致） ----
        try (MemoryStack ignored = stack.push()) {
            VkImageMemoryBarrier2.Buffer imgBarrier = VkImageMemoryBarrier2.calloc(1, stack).sType$Default();
            imgBarrier.srcStageMask(VK_PIPELINE_STAGE_TRANSFER_BIT);
            imgBarrier.srcAccessMask(VK_ACCESS_TRANSFER_WRITE_BIT);
            imgBarrier.dstStageMask(VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT);
            imgBarrier.dstAccessMask(0);
            imgBarrier.oldLayout(VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL);
            imgBarrier.newLayout(KHRSwapchain.VK_IMAGE_LAYOUT_PRESENT_SRC_KHR);
            imgBarrier.srcQueueFamilyIndex(-1);
            imgBarrier.dstQueueFamilyIndex(-1);
            imgBarrier.image(swapchainImage);
            imgBarrier.subresourceRange()
                    .aspectMask(VK_IMAGE_ASPECT_COLOR_BIT)
                    .baseMipLevel(0)
                    .levelCount(1)
                    .baseArrayLayer(0)
                    .layerCount(1);

            VkMemoryBarrier2.Buffer memBarrier = VkMemoryBarrier2.calloc(1, stack).sType$Default();
            memBarrier.srcStageMask(VK_PIPELINE_STAGE_TRANSFER_BIT);
            memBarrier.srcAccessMask(VK_ACCESS_TRANSFER_READ_BIT);
            memBarrier.dstStageMask(VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT);
            memBarrier.dstAccessMask(VK_ACCESS_MEMORY_READ_BIT | VK_ACCESS_MEMORY_WRITE_BIT);

            VkDependencyInfo dependencyInfo = VkDependencyInfo.calloc(stack).sType$Default();
            dependencyInfo.pMemoryBarriers(memBarrier);
            dependencyInfo.pImageMemoryBarriers(imgBarrier);
            KHRSynchronization2.vkCmdPipelineBarrier2KHR(cmdBuf, dependencyInfo);
        }

        // ---- 提交并与 acquire/present semaphore 挂接（与原版一致） ----
        metalfxhelper$submit(encoder, cmdBuf);
    }

    /**
     * 记录一条 image 布局迁移 barrier（COLOR 全 subresource，queue family 不迁移）。
     * 自带 MemoryStack 帧，调用方无需 push/pop。
     */
    @Unique
    private static void metalfxhelper$imageBarrier(VkCommandBuffer cmdBuf, MemoryStack stack, long image,
                                                   long srcStage, long srcAccess,
                                                   long dstStage, long dstAccess,
                                                   int oldLayout, int newLayout) {
        try (MemoryStack ignored = stack.push()) {
            VkImageMemoryBarrier2.Buffer barrier = VkImageMemoryBarrier2.calloc(1, stack).sType$Default();
            barrier.srcStageMask(srcStage);
            barrier.srcAccessMask(srcAccess);
            barrier.dstStageMask(dstStage);
            barrier.dstAccessMask(dstAccess);
            barrier.oldLayout(oldLayout);
            barrier.newLayout(newLayout);
            barrier.srcQueueFamilyIndex(-1);
            barrier.dstQueueFamilyIndex(-1);
            barrier.image(image);
            barrier.subresourceRange()
                    .aspectMask(VK_IMAGE_ASPECT_COLOR_BIT)
                    .baseMipLevel(0)
                    .levelCount(1)
                    .baseArrayLayer(0)
                    .layerCount(1);

            VkDependencyInfo dependencyInfo = VkDependencyInfo.calloc(stack).sType$Default();
            dependencyInfo.pImageMemoryBarriers(barrier);
            KHRSynchronization2.vkCmdPipelineBarrier2KHR(cmdBuf, dependencyInfo);
        }
    }

    /**
     * vkEndCommandBuffer + waitSemaphore(acquire) + execute + signalSemaphore(present)，
     * 与原版 blitFromTexture 的提交序列完全一致。
     */
    @Unique
    private void metalfxhelper$submit(VulkanCommandEncoder encoder, VkCommandBuffer cmdBuf) {
        int endResult = VK12.vkEndCommandBuffer(cmdBuf);
        if (endResult != VK_SUCCESS) {
            throw new IllegalStateException("Failed to end VkCommandBuffer, VkResult=" + endResult);
        }
        encoder.waitSemaphore(acquireSemaphores[currentAcquireSemaphore], 0L, VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT);
        encoder.execute(cmdBuf);
        encoder.signalSemaphore(presentSemaphores[currentImageIndex], 0L, VK_PIPELINE_STAGE_TRANSFER_BIT);
    }
}
