package metalfxhelper.modid.client.mixin;

import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vulkan.VulkanDevice;
import com.mojang.blaze3d.vulkan.VulkanGpuSurface;
import it.unimi.dsi.fastutil.longs.LongList;
import metalfxhelper.modid.client.FSR1Manager;
import metalfxhelper.modid.client.fsr.FSR1VulkanManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import org.lwjgl.vulkan.VkPhysicalDevice;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.lang.reflect.Field;

/**
 * FSR 1.0 Vulkan 注入点：在 blitFromTexture 之前执行 FSR 超分
 */
@Mixin(VulkanGpuSurface.class)
public abstract class VulkanGpuSurfacePresentMixin {

    @Shadow private LongList swapchainImages;
    @Shadow private int currentImageIndex;
    @Shadow private VulkanDevice device;

    // 标记是否已经初始化 FSR
    private static boolean fsrInitialized = false;

    @Inject(method = "present", at = @At("HEAD"))
    private void onPresent(CallbackInfo ci) {
        if (currentImageIndex < 0 || currentImageIndex >= swapchainImages.size()) {
            return;
        }

        // 获取 FSR1Manager 状态 - Kotlin object 直接用 INSTANCE
        if (!FSR1Manager.INSTANCE.getEnabled()) {
            return; // FSR 未启用，走正常流程
        }

        // 初始化 FSR Vulkan 上下文（只执行一次）
        if (!fsrInitialized) {
            initializeFSR();
        }

        // 如果 FSR Vulkan 未初始化成功，回退到正常流程
        if (!FSR1VulkanManager.getInstance().isEnabled()) {
            return;
        }

        // 获取当前 swapchain image
        long swapchainImage = swapchainImages.getLong(currentImageIndex);

        // 获取 mainRenderTarget 的 texture view
        GpuTextureView srcTextureView = getMainRenderTargetTextureView();
        if (srcTextureView == null) {
            System.out.println("[FSR Vulkan] ❌ 无法获取 mainRenderTarget texture view");
            return;
        }

        // 获取分辨率
        int[] resolutions = getResolutions();
        int renderW = resolutions[0];
        int renderH = resolutions[1];
        int displayW = resolutions[2];
        int displayH = resolutions[3];

        // 获取 CommandEncoder
        var commandEncoder = RenderSystem.getDevice().createCommandEncoder();

        // 执行 FSR 超分
        FSR1VulkanManager.getInstance().upscale(
                srcTextureView,
                swapchainImage,
                renderW, renderH,
                displayW, displayH,
                commandEncoder
        );
    }

    /**
     * 初始化 FSR Vulkan 上下文
     */
    private void initializeFSR() {
        try {
            System.out.println("[FSR Vulkan] 初始化 FSR Vulkan 上下文...");

            // 获取 GpuDevice
            GpuDevice gpuDevice = RenderSystem.getDevice();
            if (gpuDevice == null) {
                System.out.println("[FSR Vulkan] ❌ 无法获取 GpuDevice");
                return;
            }

            // 获取 VkPhysicalDevice (从 FSR1Manager 获取，由 VulkanBackendCreateDeviceMixin 保存)
            VkPhysicalDevice physicalDevice = FSR1Manager.INSTANCE.getPhysicalDevice();
            if (physicalDevice == null) {
                System.out.println("[FSR Vulkan] ❌ 无法获取 PhysicalDevice (尚未初始化)");
                return;
            }

            // 初始化 FSR1VulkanManager
            FSR1VulkanManager.getInstance().initialize(gpuDevice, physicalDevice);
            fsrInitialized = true;

            System.out.println("[FSR Vulkan] ✅ FSR Vulkan 初始化完成");

        } catch (Exception e) {
            System.out.println("[FSR Vulkan] ❌ 初始化异常: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * 获取 mainRenderTarget 的 color texture view
     */
    private GpuTextureView getMainRenderTargetTextureView() {
        try {
            Minecraft mc = Minecraft.getInstance();
            GameRenderer gameRenderer = mc.gameRenderer;

            var renderTarget = gameRenderer.mainRenderTarget();
            if (renderTarget == null) {
                return null;
            }

            return renderTarget.getColorTextureView();

        } catch (Exception e) {
            System.out.println("[FSR Vulkan] ❌ 获取 mainRenderTarget 失败: " + e.getMessage());
            return null;
        }
    }

    /**
     * 获取渲染和显示分辨率
     */
    private int[] getResolutions() {
        Minecraft mc = Minecraft.getInstance();
        var window = mc.getWindow();

        int displayW = window.getWidth();
        int displayH = window.getHeight();

        int renderW = displayW;
        int renderH = displayH;

        try {
            var renderTarget = mc.gameRenderer.mainRenderTarget();
            if (renderTarget != null) {
                renderW = renderTarget.width;
                renderH = renderTarget.height;
            }
        } catch (Exception e) {
            // 使用默认值
        }

        return new int[]{renderW, renderH, displayW, displayH};
    }
}
