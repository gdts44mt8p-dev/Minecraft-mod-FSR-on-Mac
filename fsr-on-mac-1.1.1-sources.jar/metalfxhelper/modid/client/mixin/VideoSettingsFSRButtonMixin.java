package metalfxhelper.modid.client.mixin;

import metalfxhelper.modid.client.FSR1Manager;
import metalfxhelper.modid.client.FSR1Preset;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.OptionsList;
import net.minecraft.client.gui.screens.options.VideoSettingsScreen;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 在视频设置界面添加 FSR 1.0 档位切换按钮
 * 点击按钮循环切换 FSR 档位，按钮文字实时反映当前档位（无 Toast 弹窗）
 */
@Mixin(VideoSettingsScreen.class)
public class VideoSettingsFSRButtonMixin {

    @Inject(method = "addOptions", at = @At("TAIL"))
    private void onAddOptions(CallbackInfo ci) {
        System.out.println("[FSR VideoSettings] Injecting FSR button into VideoSettingsScreen...");

        VideoSettingsScreen self = (VideoSettingsScreen) (Object) this;

        // 获取 OptionsList
        OptionsList optionsList = ((OptionsSubScreenAccessor) self).metalfxhelper$getList();
        if (optionsList == null) {
            System.out.println("[FSR VideoSettings] OptionsList is null, skipping button injection");
            return;
        }

        // 创建 FSR 切换按钮
        Button fsrButton = Button.builder(
            getFSRButtonText(),
            button -> {
                // 切换 FSR 档位
                FSR1Preset newPreset = FSR1Manager.INSTANCE.cyclePreset();
                System.out.println("[FSR VideoSettings] Button clicked, switched to: " + newPreset.getDisplayName());

                // 更新按钮文字
                button.setMessage(getFSRButtonText());
            }
        ).width(200).build();

        // 添加到大选项列表（占一整行）
        optionsList.addBig(fsrButton);
        System.out.println("[FSR VideoSettings] FSR button added successfully!");
    }

    @Unique
    private Component getFSRButtonText() {
        FSR1Preset preset = FSR1Manager.INSTANCE.getCurrentPreset();
        String scaleText;
        if (preset == FSR1Preset.OFF) {
            scaleText = "关闭";
        } else if (preset == FSR1Preset.UPSCALED) {
            scaleText = "超分 (100% + 锐化)";
        } else {
            scaleText = preset.getDisplayName() + " (" + (int)(preset.getRenderScale() * 100) + "%)";
        }
        return Component.literal("AMD FSR 1.0: " + scaleText);
    }
}
