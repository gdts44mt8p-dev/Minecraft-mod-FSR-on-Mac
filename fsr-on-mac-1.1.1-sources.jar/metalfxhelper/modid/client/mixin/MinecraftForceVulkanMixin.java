package metalfxhelper.modid.client.mixin;

import com.mojang.blaze3d.platform.MessageBox;
import net.minecraft.client.Minecraft;
import net.minecraft.client.main.GameConfig;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.util.List;

/**
 * 启动时自动将图形 API 偏好设为 Vulkan。
 *
 * <p>本 mod（FSR on mac）只在 Minecraft 26.2 的 Vulkan 渲染器下工作，
 * 但多数玩家的图形 API 设置停留在"默认"（实际走 OpenGL）。</p>
 *
 * <h3>实现原理</h3>
 * <p>在 {@code Minecraft(GameConfig)} 构造函数 HEAD 注入。此时
 * {@code this.options = new Options(this, this.gameDirectory)} 尚未执行，
 * 但 {@code gameConfig.location.gameDirectory} 已可用。本 Mixin 直接改写
 * options.txt 中 {@code preferredGraphicsBackend} 的持久化值为
 * {@code "vulkan"}；紧随其后的 {@code new Options(...)} 在加载时就会读到
 * vulkan，渲染后端选择逻辑（{@code preferredGraphicsBackend.getBackendsToTry()}）
 * 随之自然选中 Vulkan。</p>
 *
 * <p>选择文件级改写而非改内存 OptionInstance，是因为构造函数 HEAD 时
 * {@code this.options} 尚未赋值，内存对象还拿不到；而文件是此刻唯一已
 * 就绪、且能被后续 {@code new Options(...)} 消费的状态源。</p>
 *
 * <h3>关于 Vulkan 可用性（为什么不预探测）</h3>
 * <p>MC 26.2 的 {@code VulkanBackend.checkBackendAvailable()} 依赖 GLFW 已初始化，
 * 而 GLFW 是在本构造函数后段才由 {@code RenderSystem.initBackendSystem()} 初始化的，
 * 因此在 HEAD 处无法可靠预探测（会得到 "GLFW not initialized" 假阴性）。</p>
 *
 * <p>好在 MC 26.2 自带两层兜底，我们直接复用：</p>
 * <ul>
 *   <li><b>后端回退</b>：若设为 vulkan 后创建失败，MC 会自动回退到 OpenGL
 *       并打日志，游戏不闪退（本 mod 的 FSR 不生效，但不影响游玩）。</li>
 *   <li><b>崩溃保护</b>：若 Vulkan 路径异常退出（options.txt 留下
 *       {@code startedCleanly:false}），下次启动 MC 会自动把
 *       VULKAN 降级为 DEFAULT、DEFAULT 降级为 OPENGL，防止崩溃循环。</li>
 * </ul>
 *
 * <p>因此本 Mixin 的策略是：<b>干净启动时直接改写为 vulkan</b>，
 * 把"不可用就回退"交给 MC 原生机制处理。这比在错误时机强行探测更可靠。</p>
 *
 * <p>注意：若玩家通过启动参数 {@code --graphicsBackend} 强制指定了 API，
 * MC 会忽略游戏内设置（并打警告日志），本 Mixin 的改动不生效，属正常行为。</p>
 */
@Mixin(Minecraft.class)
public abstract class MinecraftForceVulkanMixin {

    /**
     * 在 {@code Minecraft(GameConfig)} 构造函数 HEAD 注入，
     * 抢在 {@code new Options(...)} 之前改写 options.txt。
     *
     * <p>注意：注入到构造函数 {@code super()} 调用之前（HEAD）的 handler
     * 必须声明为 {@code static}，否则 Mixin 会以
     * "handler before super() invocation must be static" 拒绝变换。</p>
     */
    @Inject(method = "<init>(Lnet/minecraft/client/main/GameConfig;)V", at = @At("HEAD"))
    private static void metalfxhelper$forceVulkanAtStartup(GameConfig gameConfig, CallbackInfo ci) {
        try {
            metalfxhelper$rewriteSavedBackendToVulkan(gameConfig);
        } catch (Throwable t) {
            // 任何失败都不应阻断游戏启动
            System.out.println("[FSR ForceVulkan] ⚠️ 设置 Vulkan 失败（不影响启动）: " + t.getMessage());
        }
    }

    /**
     * 改写 options.txt 中 preferredGraphicsBackend 的持久化值为 "vulkan"。
     *
     * <p>安全规则（与 MC 崩溃保护协同）：若检测到上次启动未正常结束
     * （options.txt 含 {@code startedCleanly:false}），则不改动——把降级
     * 决策留给 MC 原生逻辑，避免在 Vulkan 起不来的机器上造成崩溃循环。</p>
     *
     * <p>options.txt 行格式（由 {@code Options.save()} 产生）：
     * {@code preferredGraphicsBackend:"vulkan"}（值为 JSON 字符串）。</p>
     */
    private static void metalfxhelper$rewriteSavedBackendToVulkan(GameConfig gameConfig) {
        // 1. 定位 options.txt
        if (gameConfig == null || gameConfig.location == null || gameConfig.location.gameDirectory == null) {
            System.out.println("[FSR ForceVulkan] ⚠️ gameDirectory 不可用，跳过");
            return;
        }
        File optionsFile = new File(gameConfig.location.gameDirectory, "options.txt");
        if (!optionsFile.exists()) {
            // 首次启动，没有 options.txt：玩家没有历史偏好，无需改写。
            // MC 26.2 在 DEFAULT 下本就会优先尝试 Vulkan（getBackendsToTry() 顺序）。
            return;
        }

        try {
            List<String> lines = Files.readAllLines(optionsFile.toPath(), StandardCharsets.UTF_8);

            // 2. 崩溃保护检测：上次启动未干净退出则不强制改回 Vulkan
            for (String line : lines) {
                if (line.trim().equalsIgnoreCase("startedCleanly:false")) {
                    System.out.println("[FSR ForceVulkan] ⚠️ 检测到上次启动异常退出，本次不强制改图形 API（交给 MC 崩溃保护），稍后可手动切回 Vulkan");
                    return;
                }
            }

            // 3. 定位并替换/追加 preferredGraphicsBackend 行
            final String key = "preferredGraphicsBackend:";
            final String vulkanLine = "preferredGraphicsBackend:\"vulkan\"";
            boolean found = false;
            boolean alreadyVulkan = false;
            for (int i = 0; i < lines.size(); i++) {
                String line = lines.get(i);
                if (line.startsWith(key)) {
                    found = true;
                    if (line.contains("\"vulkan\"")) {
                        alreadyVulkan = true;
                    } else {
                        lines.set(i, vulkanLine);
                    }
                    break;
                }
            }

            if (alreadyVulkan) {
                System.out.println("[FSR ForceVulkan] 图形 API 已是 Vulkan，无需修改");
                return;
            }
            if (!found) {
                lines.add(vulkanLine);
            }

            // 4. 写回
            Files.write(
                optionsFile.toPath(),
                lines,
                StandardCharsets.UTF_8,
                StandardOpenOption.CREATE,
                StandardOpenOption.TRUNCATE_EXISTING,
                StandardOpenOption.WRITE
            );
            System.out.println("[FSR ForceVulkan] ✅ 已将图形 API 偏好设为 Vulkan（options.txt 已更新），本次启动使用 Vulkan 渲染器");
        } catch (java.io.IOException e) {
            System.out.println("[FSR ForceVulkan] ⚠️ 读写 options.txt 失败: " + e.getMessage());
        }
    }
}
