package metalfxhelper.modid.client.mixin;

import metalfxhelper.modid.client.FSR1Manager;
import metalfxhelper.modid.client.FSR1Preset;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 注册 FSR 1.0 切换按键
 * 默认按键: F8 (可自定义)
 * 切换时仅打印日志，不弹出 Toast，避免遮挡界面
 */
@Mixin(Minecraft.class)
public class MinecraftFSRKeyMixin {

    @Unique
    private static final KeyMapping FSR_TOGGLE_KEY = new KeyMapping(
        "key.fsr.toggle",
        GLFW.GLFW_KEY_F8,
        KeyMapping.Category.MISC
    );

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        // 检查按键是否被按下
        while (FSR_TOGGLE_KEY.consumeClick()) {
            toggleFSR();
        }
    }

    @Unique
    private void toggleFSR() {
        FSR1Preset newPreset = FSR1Manager.INSTANCE.cyclePreset();
        String scaleText;
        if (newPreset == FSR1Preset.OFF) {
            scaleText = "";
        } else if (newPreset == FSR1Preset.UPSCALED) {
            scaleText = " (100% + 超分辨率锐化)";
        } else {
            scaleText = " (渲染比例: " + (int)(newPreset.getRenderScale() * 100) + "%)";
        }

        // 打印到游戏日志和控制台
        System.out.println("[FSR] 按键切换档位: " + newPreset.getDisplayName() + scaleText);
    }
}
