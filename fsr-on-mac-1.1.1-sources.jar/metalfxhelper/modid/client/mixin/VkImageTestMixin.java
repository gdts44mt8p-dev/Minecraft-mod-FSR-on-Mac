package metalfxhelper.modid.client.mixin;

import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.vulkan.VulkanDevice;
import com.mojang.blaze3d.vulkan.VulkanGpuTexture;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.VK10;
import org.lwjgl.vulkan.VkDevice;
import org.lwjgl.vulkan.VkMemoryRequirements;
import org.lwjgl.vulkan.VkPhysicalDevice;
import org.lwjgl.vulkan.VkPhysicalDeviceProperties;

import it.unimi.dsi.fastutil.longs.LongList;

/**
 * 测试 Mixin：验证获取底层 VkImage 句柄
 * 
 * 测试目标：
 * 1. 通过 device.createTexture() 创建的 texture 是否能获取 VkImage
 * 2. swapchain image 是否也能获取 VkImage（通过反射或其他方式）
 * 3. 获取的 VkImage 句柄是否有效（非零）
 */
@Mixin(Minecraft.class)
public class VkImageTestMixin {

    private static boolean tested = false;
    private static int testFrameCount = 0;

    @Inject(method = "runTick", at = @At("TAIL"))
    private void onRunTick(CallbackInfo ci) {
        testFrameCount++;
        
        // 第30帧时进行测试（确保渲染已经初始化完成）
        if (testFrameCount == 30 && !tested) {
            tested = true;
            runVkImageTests();
        }
    }

    private void runVkImageTests() {
        System.out.println("\n========================================");
        System.out.println("[VkImageTest] 开始 VkImage 句柄测试");
        System.out.println("========================================\n");

        try {
            test1_CreateTextureVkImage();
            test2_SwapchainImageVkImage();
            test3_VkImageHandleValidity();
            
        } catch (Exception e) {
            System.out.println("[VkImageTest] 测试过程中发生异常: " + e.getMessage());
            e.printStackTrace();
        }

        System.out.println("\n========================================");
        System.out.println("[VkImageTest] 测试完成");
        System.out.println("========================================\n");
    }

    /**
     * 测试1：通过 createTexture 创建的 texture 获取 VkImage
     */
    private void test1_CreateTextureVkImage() {
        System.out.println("[VkImageTest] --- 测试1: createTexture 的 VkImage ---");
        
        try {
            GpuDevice device = RenderSystem.getDevice();
            if (device == null) {
                System.out.println("[VkImageTest] ❌ GpuDevice 为 null");
                return;
            }

            // 创建测试 texture
            GpuTexture testTexture = device.createTexture(
                "vkimage_test", 
                1, 
                com.mojang.blaze3d.GpuFormat.RGBA8_UNORM, 
                64, 64, 1, 1
            );
            
            if (testTexture == null) {
                System.out.println("[VkImageTest] ❌ 创建 texture 失败");
                return;
            }

            System.out.println("[VkImageTest] Texture 类型: " + testTexture.getClass().getName());

            // 检查是否是 VulkanGpuTexture
            if (testTexture instanceof VulkanGpuTexture) {
                VulkanGpuTexture vulkanTex = (VulkanGpuTexture) testTexture;
                long vkImage = vulkanTex.vkImage();
                
                System.out.println("[VkImageTest] ✅ 是 VulkanGpuTexture");
                System.out.println("[VkImageTest] VkImage 句柄: 0x" + Long.toHexString(vkImage));
                
                if (vkImage != 0) {
                    System.out.println("[VkImageTest] ✅ VkImage 句柄有效（非零）");
                } else {
                    System.out.println("[VkImageTest] ❌ VkImage 句柄为零");
                }
            } else {
                System.out.println("[VkImageTest] ❌ 不是 VulkanGpuTexture，无法获取 VkImage");
            }

            testTexture.close();
            
        } catch (Exception e) {
            System.out.println("[VkImageTest] ❌ 测试1异常: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * 测试2：尝试获取 swapchain image 的 VkImage
     * 
     * 方法：通过反射访问 VulkanGpuSurface 的 swapchainImages 字段
     */
    private void test2_SwapchainImageVkImage() {
        System.out.println("\n[VkImageTest] --- 测试2: Swapchain Image 的 VkImage ---");
        
        try {
            Minecraft mc = Minecraft.getInstance();
            Object windowSurface = mc.windowSurface();
            
            if (windowSurface == null) {
                System.out.println("[VkImageTest] ❌ windowSurface 为 null");
                return;
            }
            
            System.out.println("[VkImageTest] windowSurface 类型: " + windowSurface.getClass().getName());

            // 检查是否是 VulkanGpuSurface
            if (windowSurface.getClass().getName().contains("GpuSurface")) {
                System.out.println("[VkImageTest] ✅ 是 GpuSurface (包装类)");
                
                // 尝试获取内部的 VulkanGpuSurface backend
                try {
                    java.lang.reflect.Field backendField = windowSurface.getClass().getDeclaredField("backend");
                    backendField.setAccessible(true);
                    Object backend = backendField.get(windowSurface);
                    
                    if (backend != null) {
                        System.out.println("[VkImageTest] GpuSurface backend 类型: " + backend.getClass().getName());
                        
                        if (backend.getClass().getName().contains("VulkanGpuSurface")) {
                            System.out.println("[VkImageTest] ✅ 内部 backend 是 VulkanGpuSurface");
                            
                            // 通过反射获取 swapchainImages
                            java.lang.reflect.Field swapchainImagesField = backend.getClass().getDeclaredField("swapchainImages");
                            swapchainImagesField.setAccessible(true);
                            Object swapchainImages = swapchainImagesField.get(backend);
                            
                            if (swapchainImages != null) {
                                System.out.println("[VkImageTest] swapchainImages 类型: " + swapchainImages.getClass().getName());
                                
                                // 尝试获取 LongList 的大小
                                if (swapchainImages instanceof LongList) {
                                    LongList longList = (LongList) swapchainImages;
                                    System.out.println("[VkImageTest] Swapchain image 数量: " + longList.size());
                                    
                                    // 打印前几个 image 的句柄
                                    for (int i = 0; i < Math.min(3, longList.size()); i++) {
                                        long imageHandle = longList.getLong(i);
                                        System.out.println("[VkImageTest]   Swapchain Image[" + i + "]: 0x" + Long.toHexString(imageHandle));
                                    }
                                    
                                    if (longList.size() > 0) {
                                        System.out.println("[VkImageTest] ✅ 成功获取 swapchain image 句柄");
                                    }
                                }
                            } else {
                                System.out.println("[VkImageTest] ❌ swapchainImages 为 null");
                            }
                            
                            // 获取 currentImageIndex
                            try {
                                java.lang.reflect.Field currentImageField = backend.getClass().getDeclaredField("currentImageIndex");
                                currentImageField.setAccessible(true);
                                int currentIndex = currentImageField.getInt(backend);
                                System.out.println("[VkImageTest] Current image index: " + currentIndex);
                            } catch (Exception e) {
                                System.out.println("[VkImageTest] 获取 currentImageIndex 失败: " + e.getMessage());
                            }
                        }
                    } else {
                        System.out.println("[VkImageTest] ❌ GpuSurface backend 为 null");
                    }
                } catch (Exception e) {
                    System.out.println("[VkImageTest] 获取 backend 失败: " + e.getMessage());
                    e.printStackTrace();
                }
                
            } else {
                System.out.println("[VkImageTest] ❌ 不是 GpuSurface");
            }
            
        } catch (Exception e) {
            System.out.println("[VkImageTest] ❌ 测试2异常: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * 测试3：验证 VkImage 句柄的有效性
     * 
     * 尝试使用 Vulkan API 查询 image 信息来验证句柄是否有效
     */
    private void test3_VkImageHandleValidity() {
        System.out.println("\n[VkImageTest] --- 测试3: VkImage 句柄有效性验证 ---");
        
        try {
            GpuDevice device = RenderSystem.getDevice();
            if (device == null) {
                System.out.println("[VkImageTest] ❌ GpuDevice 为 null");
                return;
            }

            // 创建测试 texture
            GpuTexture testTexture = device.createTexture(
                "vkimage_validity_test", 
                1, 
                com.mojang.blaze3d.GpuFormat.RGBA8_UNORM, 
                128, 128, 1, 1
            );
            
            if (!(testTexture instanceof VulkanGpuTexture)) {
                System.out.println("[VkImageTest] ❌ 不是 VulkanGpuTexture");
                return;
            }

            VulkanGpuTexture vulkanTex = (VulkanGpuTexture) testTexture;
            long vkImage = vulkanTex.vkImage();
            
            System.out.println("[VkImageTest] 测试 VkImage: 0x" + Long.toHexString(vkImage));
            
            // 获取 VulkanDevice 来访问 vkDevice
            // GpuDevice 包装了 GpuDeviceBackend，需要通过反射获取 backend
            try {
                java.lang.reflect.Field backendField = device.getClass().getDeclaredField("backend");
                backendField.setAccessible(true);
                Object backend = backendField.get(device);
                
                if (backend instanceof VulkanDevice) {
                    VulkanDevice vulkanDevice = (VulkanDevice) backend;
                    VkDevice vkDevice = vulkanDevice.vkDevice();
                    
                    System.out.println("[VkImageTest] VkDevice: 0x" + Long.toHexString(vkDevice.address()));
                    
                    // 尝试使用 vkGetImageMemoryRequirements 验证句柄
                    try {
                        MemoryStack stack = MemoryStack.stackPush();
                        try {
                            VkMemoryRequirements memReqs = VkMemoryRequirements.calloc(stack);
                            VK10.vkGetImageMemoryRequirements(vkDevice, vkImage, memReqs);
                            
                            System.out.println("[VkImageTest] ✅ vkGetImageMemoryRequirements 成功");
                            System.out.println("[VkImageTest]   内存大小: " + memReqs.size() + " bytes");
                            System.out.println("[VkImageTest]   内存对齐: " + memReqs.alignment());
                            System.out.println("[VkImageTest]   内存类型位: 0x" + Integer.toHexString(memReqs.memoryTypeBits()));
                        } finally {
                            stack.pop();
                        }
                    } catch (Exception e) {
                        System.out.println("[VkImageTest] ❌ vkGetImageMemoryRequirements 失败: " + e.getMessage());
                    }
                    
                    // 尝试获取 physical device 信息
                    try {
                        java.lang.reflect.Field physDeviceField = vulkanDevice.getClass().getDeclaredField("physicalDevice");
                        physDeviceField.setAccessible(true);
                        VkPhysicalDevice physDevice = (VkPhysicalDevice) physDeviceField.get(vulkanDevice);
                        
                        System.out.println("[VkImageTest] VkPhysicalDevice: 0x" + Long.toHexString(physDevice.address()));
                        
                        // 查询设备属性
                        MemoryStack stack = MemoryStack.stackPush();
                        try {
                            VkPhysicalDeviceProperties props = VkPhysicalDeviceProperties.calloc(stack);
                            VK10.vkGetPhysicalDeviceProperties(physDevice, props);
                            
                            System.out.println("[VkImageTest] ✅ 设备属性查询成功");
                            System.out.println("[VkImageTest]   设备名称: " + props.deviceNameString());
                            System.out.println("[VkImageTest]   Vulkan 版本: " + 
                                VK10.VK_VERSION_MAJOR(props.apiVersion()) + "." +
                                VK10.VK_VERSION_MINOR(props.apiVersion()) + "." +
                                VK10.VK_VERSION_PATCH(props.apiVersion()));
                        } finally {
                            stack.pop();
                        }
                    } catch (Exception e) {
                        System.out.println("[VkImageTest] ⚠️ Physical device 查询失败: " + e.getMessage());
                    }
                    
                } else {
                    System.out.println("[VkImageTest] ❌ Backend 不是 VulkanDevice: " + backend.getClass().getName());
                }
            } catch (Exception e) {
                System.out.println("[VkImageTest] ❌ 获取 backend 失败: " + e.getMessage());
            }

            testTexture.close();
            
        } catch (Exception e) {
            System.out.println("[VkImageTest] ❌ 测试3异常: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
