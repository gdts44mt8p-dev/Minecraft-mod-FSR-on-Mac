package metalfxhelper.modid.client.mixin;

import com.mojang.blaze3d.platform.Window;
import metalfxhelper.modid.client.FSR1Manager;
import metalfxhelper.modid.client.FSR1Preset;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * FSR 1.0 Window Mixin - 修改 getWidth/getHeight 返回 FSR 尺寸，但 GUI 使用物理尺寸
 *
 * 关键设计：
 * 1. getWidth()/getHeight() 返回 FSR 尺寸（用于 3D 渲染低分辨率）
 * 2. getGuiScaledWidth()/getGuiScaledHeight() 返回物理尺寸（用于 GUI 正常显示）
 * 3. FSR 的低分辨率渲染通过修改 Window 尺寸实现
 */
@Mixin(Window.class)
public class WindowFSRMixin {

    @Shadow
    private int framebufferWidth;

    @Shadow
    private int framebufferHeight;

    @Shadow
    private int guiScaledWidth;

    @Shadow
    private int guiScaledHeight;

    /** FSR 逻辑渲染宽度 */
    @Unique
    private int metalfxhelper$fsrWidth = 0;

    /** FSR 逻辑渲染高度 */
    @Unique
    private int metalfxhelper$fsrHeight = 0;

    /** FSR 是否激活 */
    @Unique
    private boolean metalfxhelper$fsrActive = false;

    /**
     * 修改 getWidth()，在 FSR 启用时返回 FSR 尺寸
     */
    @Inject(method = "getWidth", at = @At("RETURN"), cancellable = true)
    private void onGetWidth(CallbackInfoReturnable<Integer> cir) {
        if (metalfxhelper$fsrActive && metalfxhelper$fsrWidth > 0) {
            cir.setReturnValue(metalfxhelper$fsrWidth);
        }
    }

    /**
     * 修改 getHeight()，在 FSR 启用时返回 FSR 尺寸
     */
    @Inject(method = "getHeight", at = @At("RETURN"), cancellable = true)
    private void onGetHeight(CallbackInfoReturnable<Integer> cir) {
        if (metalfxhelper$fsrActive && metalfxhelper$fsrHeight > 0) {
            cir.setReturnValue(metalfxhelper$fsrHeight);
        }
    }

    /**
     * 修改 getGuiScaledWidth()，始终返回物理尺寸
     */
    @Inject(method = "getGuiScaledWidth", at = @At("RETURN"), cancellable = true)
    private void onGetGuiScaledWidth(CallbackInfoReturnable<Integer> cir) {
        if (metalfxhelper$fsrActive) {
            // 返回物理尺寸的 guiScaledWidth
            cir.setReturnValue(guiScaledWidth);
        }
    }

    /**
     * 修改 getGuiScaledHeight()，始终返回物理尺寸
     */
    @Inject(method = "getGuiScaledHeight", at = @At("RETURN"), cancellable = true)
    private void onGetGuiScaledHeight(CallbackInfoReturnable<Integer> cir) {
        if (metalfxhelper$fsrActive) {
            // 返回物理尺寸的 guiScaledHeight
            cir.setReturnValue(guiScaledHeight);
        }
    }

    /**
     * 更新 FSR 分辨率（由 FSR1Manager 调用）
     *
     * @param width  FSR 逻辑渲染宽度
     * @param height FSR 逻辑渲染高度
     * @param active FSR 是否激活
     */
    @Unique
    public void metalfxhelper$updateFSRResolution(int width, int height, boolean active) {
        this.metalfxhelper$fsrWidth = width;
        this.metalfxhelper$fsrHeight = height;
        this.metalfxhelper$fsrActive = active;

        if (active) {
            System.out.println("[WindowFSRMixin] FSR 激活，逻辑分辨率: " + width + "x" + height +
                " (物理分辨率: " + framebufferWidth + "x" + framebufferHeight + ")");
        } else {
            System.out.println("[WindowFSRMixin] FSR 关闭");
        }
    }

    /**
     * 获取物理 framebuffer 宽度（原始 GLFW 尺寸）
     */
    @Unique
    public int metalfxhelper$getPhysicalWidth() {
        return framebufferWidth;
    }

    /**
     * 获取物理 framebuffer 高度（原始 GLFW 尺寸）
     */
    @Unique
    public int metalfxhelper$getPhysicalHeight() {
        return framebufferHeight;
    }

    /**
     * 获取当前 FSR 逻辑宽度
     */
    @Unique
    public int metalfxhelper$getFSRWidth() {
        return metalfxhelper$fsrActive ? metalfxhelper$fsrWidth : 0;
    }

    /**
     * 获取当前 FSR 逻辑高度
     */
    @Unique
    public int metalfxhelper$getFSRHeight() {
        return metalfxhelper$fsrActive ? metalfxhelper$fsrHeight : 0;
    }

    /**
     * 检查 FSR 是否激活
     */
    @Unique
    public boolean metalfxhelper$isFSRActive() {
        return metalfxhelper$fsrActive;
    }
}
