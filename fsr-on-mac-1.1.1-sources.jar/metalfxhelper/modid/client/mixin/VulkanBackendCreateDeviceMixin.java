package metalfxhelper.modid.client.mixin;

import com.mojang.blaze3d.vulkan.VulkanBackend;
import com.mojang.blaze3d.vulkan.VulkanPhysicalDevice;
import metalfxhelper.modid.client.FSR1Manager;
import org.lwjgl.vulkan.VkPhysicalDevice;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

import java.util.Collection;

@Mixin(VulkanBackend.class)
public abstract class VulkanBackendCreateDeviceMixin {

    @ModifyArg(
            method = "createDevice(JLcom/mojang/blaze3d/shaders/ShaderSource;Lcom/mojang/blaze3d/shaders/GpuDebugOptions;Ljava/lang/Runnable;)Lcom/mojang/blaze3d/systems/GpuDevice;",
            at = @At(
                    value = "INVOKE",
                    target = "Lcom/mojang/blaze3d/vulkan/VulkanBackend;createDevice(Ljava/util/Collection;Lcom/mojang/blaze3d/vulkan/VulkanPhysicalDevice;Ljava/util/Set;)Lorg/lwjgl/vulkan/VkDevice;"
            ),
            index = 0
    )
    private Collection<String> addMetalObjectsExtension(Collection<String> deviceExtensions) {
        System.out.println("[MetalFX] 原扩展列表: " + deviceExtensions);
        deviceExtensions.add("VK_EXT_metal_objects");
        System.out.println("[MetalFX] 已添加 VK_EXT_metal_objects");
        return deviceExtensions;
    }

    @ModifyArg(
            method = "createDevice(JLcom/mojang/blaze3d/shaders/ShaderSource;Lcom/mojang/blaze3d/shaders/GpuDebugOptions;Ljava/lang/Runnable;)Lcom/mojang/blaze3d/systems/GpuDevice;",
            at = @At(
                    value = "INVOKE",
                    target = "Lcom/mojang/blaze3d/vulkan/VulkanDevice;<init>(Lcom/mojang/blaze3d/shaders/ShaderSource;Lcom/mojang/blaze3d/vulkan/VulkanInstance;Lcom/mojang/blaze3d/vulkan/VulkanPhysicalDevice;Ljava/util/Set;Lorg/lwjgl/vulkan/VkDevice;JLcom/mojang/blaze3d/vulkan/checkpoints/CheckpointExtension;)V"
            ),
            index = 2
    )
    private VulkanPhysicalDevice capturePhysicalDevice(VulkanPhysicalDevice physicalDevice) {
        VkPhysicalDevice vkPhysicalDevice = physicalDevice.vkPhysicalDevice();
        FSR1Manager.INSTANCE.setPhysicalDevice(vkPhysicalDevice);
        System.out.println("[FSR1Manager] Captured VkPhysicalDevice: 0x" + Long.toHexString(vkPhysicalDevice.address()));
        return physicalDevice;
    }
}