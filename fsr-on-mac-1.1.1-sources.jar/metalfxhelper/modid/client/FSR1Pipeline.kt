package metalfxhelper.modid.client

import org.lwjgl.system.MemoryStack
import org.lwjgl.system.MemoryUtil
import org.lwjgl.vulkan.VK10.*
import org.lwjgl.vulkan.VkDevice
import org.lwjgl.vulkan.VkPhysicalDevice
import org.lwjgl.vulkan.VkPhysicalDeviceMemoryProperties
import org.lwjgl.vulkan.VkPipelineShaderStageCreateInfo
import org.lwjgl.vulkan.VkShaderModuleCreateInfo
import org.lwjgl.vulkan.VkDescriptorSetLayoutBinding
import org.lwjgl.vulkan.VkDescriptorSetLayoutCreateInfo
import org.lwjgl.vulkan.VkPipelineLayoutCreateInfo
import org.lwjgl.vulkan.VkComputePipelineCreateInfo
import org.lwjgl.vulkan.VkDescriptorPoolCreateInfo
import org.lwjgl.vulkan.VkDescriptorPoolSize
import org.lwjgl.vulkan.VkDescriptorSetAllocateInfo
import org.lwjgl.vulkan.VkWriteDescriptorSet
import org.lwjgl.vulkan.VkDescriptorImageInfo
import org.lwjgl.vulkan.VkImageCreateInfo
import org.lwjgl.vulkan.VkImageViewCreateInfo
import org.lwjgl.vulkan.VkMemoryAllocateInfo
import org.lwjgl.vulkan.VkMemoryRequirements
import org.lwjgl.vulkan.VkPushConstantRange
import org.lwjgl.vulkan.VkCommandBuffer
import org.lwjgl.util.shaderc.Shaderc
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * FSR 1.0 Vulkan Compute Pipeline - v1.0.3
 * 
 * 改进：
 * 1. 支持外部 input image（swapchain image）通过 updateInputImage 动态绑定
 * 2. 只创建 output image（input 由外部提供）
 * 3. 简化资源管理
 */
class FSR1Pipeline(
    private val device: VkDevice,
    private val physicalDevice: VkPhysicalDevice,
    val inputWidth: Int,
    val inputHeight: Int,
    val outputWidth: Int,
    val outputHeight: Int
) {
    // --- Vulkan handles ---
    var pipelineLayout: Long = 0L
        private set
    var pipeline: Long = 0L
        private set
    var descriptorSetLayout: Long = 0L
        private set
    var descriptorPool: Long = 0L
        private set
    var descriptorSet: Long = 0L
        private set

    // Output image（FSR compute shader 写入目标）
    var outputImage: Long = 0L
        private set
    var outputImageView: Long = 0L
        private set
    var outputImageMemory: Long = 0L
        private set

    // 标记是否初始化成功
    var initialized = false
        private set

    // 当前绑定的 input image view（外部 swapchain image）
    private var currentInputImageView: Long = 0L

    companion object {
        private val COMPUTE_SHADER_GLSL = FSR1Shader.COMPUTE_SHADER_GLSL

        private const val VK_FORMAT = VK_FORMAT_B8G8R8A8_UNORM
        private const val VK_IMAGE_USAGE_OUTPUT = VK_IMAGE_USAGE_STORAGE_BIT or VK_IMAGE_USAGE_TRANSFER_SRC_BIT
        
        // Push constants: 4 ints + 1 float = 20 bytes
        const val PUSH_CONSTANT_SIZE = 20
    }

    fun init() {
        if (initialized) return
        try {
            MemoryStack.stackPush().use { stack ->
                // 1. 编译 GLSL -> SPIR-V
                val spirv = compileGLSLToSPIRV()

                // 2. 创建 ShaderModule
                val shaderModule = createShaderModule(stack, spirv)

                // 3. 创建 DescriptorSetLayout (2 bindings: input image, output image)
                descriptorSetLayout = createDescriptorSetLayout(stack)

                // 4. 创建 PipelineLayout
                pipelineLayout = createPipelineLayout(stack)

                // 5. 创建 Compute Pipeline
                pipeline = createComputePipeline(stack, shaderModule)

                // 6. 销毁 ShaderModule
                vkDestroyShaderModule(device, shaderModule, null)

                // 7. 创建 output image（input image 由外部提供）
                createOutputImage(stack)

                // 8. 创建 DescriptorPool 和 DescriptorSet
                createDescriptorPoolAndSet(stack)

                // 9. 初始化 descriptor set（input 绑定为占位符，后续通过 updateInputImage 更新）
                updateDescriptorSet(stack, 0L)

                initialized = true
                println("[FSR1Pipeline] ✅ Pipeline initialized: ${inputWidth}x${inputHeight} -> ${outputWidth}x${outputHeight}")
            }
        } catch (e: Exception) {
            println("[FSR1Pipeline] ❌ 初始化失败: ${e.message}")
            e.printStackTrace()
            cleanup()
        }
    }

    /**
     * 更新 input image 绑定（用于绑定 swapchain image）
     * 
     * 由于 swapchain image 没有 image view，我们需要创建一个临时 view
     * 或者修改 shader 直接使用 image 而不是 image view
     * 
     * 实际上，对于 storage image，我们需要 image view。但 swapchain image 通常没有 view。
     * 解决方案：为 swapchain image 创建临时 image view
     */
    fun updateInputImage(swapchainImage: Long) {
        if (!initialized) return

        // 为 swapchain image 创建临时 image view
        val inputView = createTemporaryImageView(swapchainImage)
        if (inputView == 0L) return

        // 销毁旧的临时 view
        if (currentInputImageView != 0L && currentInputImageView != inputView) {
            vkDestroyImageView(device, currentInputImageView, null)
        }
        currentInputImageView = inputView

        // 更新 descriptor set
        MemoryStack.stackPush().use { stack ->
            updateDescriptorSet(stack, inputView)
        }
    }

    private fun createTemporaryImageView(image: Long): Long {
        return try {
            MemoryStack.stackPush().use { stack ->
                val createInfo = VkImageViewCreateInfo.calloc(stack)
                    .sType(VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO)
                    .image(image)
                    .viewType(VK_IMAGE_VIEW_TYPE_2D)
                    .format(VK_FORMAT)
                    .subresourceRange { it
                        .aspectMask(VK_IMAGE_ASPECT_COLOR_BIT)
                        .baseMipLevel(0)
                        .levelCount(1)
                        .baseArrayLayer(0)
                        .layerCount(1)
                    }

                val pView = stack.callocLong(1)
                val result = vkCreateImageView(device, createInfo, null, pView)
                if (result != VK_SUCCESS) {
                    println("[FSR1Pipeline] ⚠️ 创建 input image view 失败: $result")
                    0L
                } else {
                    pView.get(0)
                }
            }
        } catch (e: Exception) {
            println("[FSR1Pipeline] ⚠️ createTemporaryImageView 失败: ${e.message}")
            0L
        }
    }

    /**
     * 使用 LWJGL shaderc 在运行时编译 GLSL -> SPIR-V
     */
    private fun compileGLSLToSPIRV(): ByteBuffer {
        val compiler = Shaderc.shaderc_compiler_initialize()
        if (compiler == 0L) {
            throw RuntimeException("Failed to initialize shaderc compiler")
        }

        try {
            val result = Shaderc.shaderc_compile_into_spv(
                compiler,
                COMPUTE_SHADER_GLSL,
                Shaderc.shaderc_compute_shader,
                "fsr1_easu_rcas.comp",
                "main",
                0L // options
            )

            if (result == 0L) {
                throw RuntimeException("shaderc_compile_into_spv returned null")
            }

            try {
                val status = Shaderc.shaderc_result_get_compilation_status(result)
                if (status != Shaderc.shaderc_compilation_status_success) {
                    val errorMsg = Shaderc.shaderc_result_get_error_message(result)
                    throw RuntimeException("Shader compilation failed: $errorMsg")
                }

                val length = Shaderc.shaderc_result_get_length(result)
                if (length == 0L) {
                    throw RuntimeException("Compiled SPIR-V is empty (length=0)")
                }

                val bytes = Shaderc.shaderc_result_get_bytes(result)
                if (bytes == null) {
                    throw RuntimeException("Compiled SPIR-V bytes is null")
                }

                val spirvBuffer = MemoryUtil.memAlloc(length.toInt())
                
                val origPos = bytes.position()
                val origLimit = bytes.limit()
                
                bytes.position(0)
                bytes.limit(length.toInt())
                
                spirvBuffer.put(bytes)
                spirvBuffer.flip()
                
                bytes.position(origPos)
                bytes.limit(origLimit)
                
                println("[FSR1Pipeline] ✅ SPIR-V compiled: ${length} bytes")
                return spirvBuffer
            } finally {
                Shaderc.shaderc_result_release(result)
            }
        } finally {
            Shaderc.shaderc_compiler_release(compiler)
        }
    }

    private fun createShaderModule(stack: MemoryStack, spirv: ByteBuffer): Long {
        val createInfo = VkShaderModuleCreateInfo.calloc(stack)
            .sType(VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO)
            .pCode(spirv)

        val pShaderModule = stack.callocLong(1)
        vkCheck(vkCreateShaderModule(device, createInfo, null, pShaderModule))
        return pShaderModule.get(0)
    }

    private fun createDescriptorSetLayout(stack: MemoryStack): Long {
        val bindings = VkDescriptorSetLayoutBinding.calloc(2, stack)

        // binding 0: input image (readonly storage image)
        bindings[0]
            .binding(0)
            .descriptorType(VK_DESCRIPTOR_TYPE_STORAGE_IMAGE)
            .descriptorCount(1)
            .stageFlags(VK_SHADER_STAGE_COMPUTE_BIT)

        // binding 1: output image (writeonly storage image)
        bindings[1]
            .binding(1)
            .descriptorType(VK_DESCRIPTOR_TYPE_STORAGE_IMAGE)
            .descriptorCount(1)
            .stageFlags(VK_SHADER_STAGE_COMPUTE_BIT)

        val createInfo = VkDescriptorSetLayoutCreateInfo.calloc(stack)
            .sType(VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO)
            .pBindings(bindings)

        val pLayout = stack.callocLong(1)
        vkCheck(vkCreateDescriptorSetLayout(device, createInfo, null, pLayout))
        return pLayout.get(0)
    }

    private fun createPipelineLayout(stack: MemoryStack): Long {
        val pushConstantRange = VkPushConstantRange.calloc(1, stack)
            .stageFlags(VK_SHADER_STAGE_COMPUTE_BIT)
            .offset(0)
            .size(PUSH_CONSTANT_SIZE)

        val setLayouts = stack.longs(descriptorSetLayout)

        val createInfo = VkPipelineLayoutCreateInfo.calloc(stack)
            .sType(VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO)
            .pSetLayouts(setLayouts)
            .pPushConstantRanges(pushConstantRange)

        val pLayout = stack.callocLong(1)
        vkCheck(vkCreatePipelineLayout(device, createInfo, null, pLayout))
        return pLayout.get(0)
    }

    private fun createComputePipeline(stack: MemoryStack, shaderModule: Long): Long {
        val stageInfo = VkPipelineShaderStageCreateInfo.calloc(stack)
            .sType(VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO)
            .stage(VK_SHADER_STAGE_COMPUTE_BIT)
            .module(shaderModule)
            .pName(stack.UTF8("main"))

        val createInfo = VkComputePipelineCreateInfo.calloc(1, stack)
            .sType(VK_STRUCTURE_TYPE_COMPUTE_PIPELINE_CREATE_INFO)
            .stage(stageInfo)
            .layout(pipelineLayout)

        val pPipeline = stack.callocLong(1)
        vkCheck(vkCreateComputePipelines(device, VK_NULL_HANDLE, createInfo, null, pPipeline))
        return pPipeline.get(0)
    }

    private fun createOutputImage(stack: MemoryStack) {
        outputImage = createImage(stack, outputWidth, outputHeight, VK_IMAGE_USAGE_OUTPUT, "output")
        outputImageMemory = allocateAndBindImageMemory(stack, outputImage, "output")
        outputImageView = createImageView(stack, outputImage, "output")
    }

    private fun createImage(stack: MemoryStack, width: Int, height: Int, usage: Int, label: String): Long {
        val createInfo = VkImageCreateInfo.calloc(stack)
            .sType(VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO)
            .imageType(VK_IMAGE_TYPE_2D)
            .format(VK_FORMAT)
            .extent { it.set(width, height, 1) }
            .mipLevels(1)
            .arrayLayers(1)
            .samples(VK_SAMPLE_COUNT_1_BIT)
            .tiling(VK_IMAGE_TILING_OPTIMAL)
            .usage(usage)
            .sharingMode(VK_SHARING_MODE_EXCLUSIVE)
            .initialLayout(VK_IMAGE_LAYOUT_UNDEFINED)

        val pImage = stack.callocLong(1)
        vkCheck(vkCreateImage(device, createInfo, null, pImage))
        val image = pImage.get(0)
        println("[FSR1Pipeline] Created $label image: ${width}x${height}, handle=0x${image.toString(16)}")
        return image
    }

    private fun allocateAndBindImageMemory(stack: MemoryStack, image: Long, label: String): Long {
        val memReqs = VkMemoryRequirements.calloc(stack)
        vkGetImageMemoryRequirements(device, image, memReqs)

        val memTypeIndex = findMemoryType(stack, memReqs.memoryTypeBits(),
            VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT)

        val allocInfo = VkMemoryAllocateInfo.calloc(stack)
            .sType(VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO)
            .allocationSize(memReqs.size())
            .memoryTypeIndex(memTypeIndex)

        val pMemory = stack.callocLong(1)
        vkCheck(vkAllocateMemory(device, allocInfo, null, pMemory))
        val memory = pMemory.get(0)

        vkCheck(vkBindImageMemory(device, image, memory, 0L))
        println("[FSR1Pipeline] Bound $label memory: 0x${memory.toString(16)}, size=${memReqs.size()}")
        return memory
    }

    private fun createImageView(stack: MemoryStack, image: Long, label: String): Long {
        val createInfo = VkImageViewCreateInfo.calloc(stack)
            .sType(VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO)
            .image(image)
            .viewType(VK_IMAGE_VIEW_TYPE_2D)
            .format(VK_FORMAT)
            .subresourceRange { it
                .aspectMask(VK_IMAGE_ASPECT_COLOR_BIT)
                .baseMipLevel(0)
                .levelCount(1)
                .baseArrayLayer(0)
                .layerCount(1)
            }

        val pView = stack.callocLong(1)
        vkCheck(vkCreateImageView(device, createInfo, null, pView))
        val view = pView.get(0)
        println("[FSR1Pipeline] Created $label image view: 0x${view.toString(16)}")
        return view
    }

    private fun createDescriptorPoolAndSet(stack: MemoryStack) {
        val poolSize = VkDescriptorPoolSize.calloc(2, stack)
        poolSize[0]
            .type(VK_DESCRIPTOR_TYPE_STORAGE_IMAGE)
            .descriptorCount(2)
        poolSize[1]
            .type(VK_DESCRIPTOR_TYPE_STORAGE_IMAGE)
            .descriptorCount(2)

        val poolInfo = VkDescriptorPoolCreateInfo.calloc(stack)
            .sType(VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO)
            .maxSets(1)
            .pPoolSizes(poolSize)

        val pPool = stack.callocLong(1)
        vkCheck(vkCreateDescriptorPool(device, poolInfo, null, pPool))
        descriptorPool = pPool.get(0)

        val allocInfo = VkDescriptorSetAllocateInfo.calloc(stack)
            .sType(VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO)
            .descriptorPool(descriptorPool)
            .pSetLayouts(stack.longs(descriptorSetLayout))

        val pSet = stack.callocLong(1)
        vkCheck(vkAllocateDescriptorSets(device, allocInfo, pSet))
        descriptorSet = pSet.get(0)
        println("[FSR1Pipeline] DescriptorSet allocated: 0x${descriptorSet.toString(16)}")
    }

    private fun updateDescriptorSet(stack: MemoryStack, inputImageView: Long) {
        val writes = VkWriteDescriptorSet.calloc(2, stack)

        // Input image
        val inputImageInfo = VkDescriptorImageInfo.calloc(1, stack)
            .imageView(inputImageView)
            .imageLayout(VK_IMAGE_LAYOUT_GENERAL)

        writes[0]
            .sType(VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET)
            .dstSet(descriptorSet)
            .dstBinding(0)
            .dstArrayElement(0)
            .descriptorType(VK_DESCRIPTOR_TYPE_STORAGE_IMAGE)
            .descriptorCount(1)
            .pImageInfo(inputImageInfo)

        // Output image
        val outputImageInfo = VkDescriptorImageInfo.calloc(1, stack)
            .imageView(outputImageView)
            .imageLayout(VK_IMAGE_LAYOUT_GENERAL)

        writes[1]
            .sType(VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET)
            .dstSet(descriptorSet)
            .dstBinding(1)
            .dstArrayElement(0)
            .descriptorType(VK_DESCRIPTOR_TYPE_STORAGE_IMAGE)
            .descriptorCount(1)
            .pImageInfo(outputImageInfo)

        vkUpdateDescriptorSets(device, writes, null)
    }

    /**
     * 查找合适的 memory type index
     */
    private fun findMemoryType(stack: MemoryStack, typeFilter: Int, properties: Int): Int {
        val memProperties = VkPhysicalDeviceMemoryProperties.calloc(stack)
        vkGetPhysicalDeviceMemoryProperties(physicalDevice, memProperties)

        for (i in 0 until memProperties.memoryTypeCount()) {
            if ((typeFilter and (1 shl i)) != 0 &&
                (memProperties.memoryTypes(i).propertyFlags() and properties) == properties) {
                return i
            }
        }
        throw RuntimeException("Failed to find suitable memory type")
    }

    /**
     * 在 command buffer 中记录 FSR 1.0 compute dispatch
     */
    fun recordComputePass(commandBuffer: VkCommandBuffer) {
        if (!initialized) return

        MemoryStack.stackPush().use { stack ->
            // Bind pipeline
            vkCmdBindPipeline(commandBuffer, VK_PIPELINE_BIND_POINT_COMPUTE, pipeline)

            // Bind descriptor set
            vkCmdBindDescriptorSets(
                commandBuffer,
                VK_PIPELINE_BIND_POINT_COMPUTE,
                pipelineLayout,
                0,
                stack.longs(descriptorSet),
                null
            )

            // Push constants: inputWidth, inputHeight, outputWidth, outputHeight, sharpness
            val pushConstants = ByteBuffer.allocateDirect(PUSH_CONSTANT_SIZE).order(ByteOrder.LITTLE_ENDIAN)
            pushConstants.putInt(inputWidth)
            pushConstants.putInt(inputHeight)
            pushConstants.putInt(outputWidth)
            pushConstants.putInt(outputHeight)
            pushConstants.putFloat(0.25f) // sharpness
            pushConstants.flip()

            vkCmdPushConstants(
                commandBuffer,
                pipelineLayout,
                VK_SHADER_STAGE_COMPUTE_BIT,
                0,
                pushConstants
            )

            // Dispatch
            val groupsX = (outputWidth + 15) / 16
            val groupsY = (outputHeight + 15) / 16
            vkCmdDispatch(commandBuffer, groupsX, groupsY, 1)
        }
    }

    /**
     * 清理所有 Vulkan 资源
     */
    fun cleanup() {
        // 销毁临时 input image view
        if (currentInputImageView != 0L) {
            vkDestroyImageView(device, currentInputImageView, null)
            currentInputImageView = 0L
        }

        if (pipeline != 0L) {
            vkDestroyPipeline(device, pipeline, null)
            pipeline = 0L
        }
        if (pipelineLayout != 0L) {
            vkDestroyPipelineLayout(device, pipelineLayout, null)
            pipelineLayout = 0L
        }
        if (descriptorSet != 0L) {
            descriptorSet = 0L
        }
        if (descriptorPool != 0L) {
            vkDestroyDescriptorPool(device, descriptorPool, null)
            descriptorPool = 0L
        }
        if (descriptorSetLayout != 0L) {
            vkDestroyDescriptorSetLayout(device, descriptorSetLayout, null)
            descriptorSetLayout = 0L
        }
        if (outputImageView != 0L) {
            vkDestroyImageView(device, outputImageView, null)
            outputImageView = 0L
        }
        if (outputImage != 0L) {
            vkDestroyImage(device, outputImage, null)
            outputImage = 0L
        }
        if (outputImageMemory != 0L) {
            vkFreeMemory(device, outputImageMemory, null)
            outputImageMemory = 0L
        }
        initialized = false
        println("[FSR1Pipeline] Cleanup complete")
    }

    private fun vkCheck(result: Int) {
        if (result != VK_SUCCESS) {
            throw RuntimeException("Vulkan error: $result")
        }
    }
}
