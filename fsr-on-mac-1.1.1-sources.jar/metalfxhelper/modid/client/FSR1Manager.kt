package metalfxhelper.modid.client

import com.google.gson.Gson
import com.google.gson.JsonObject
import com.mojang.blaze3d.vulkan.VulkanDevice
import net.fabricmc.loader.api.FabricLoader
import org.lwjgl.system.MemoryStack
import org.lwjgl.vulkan.VK10.*
import org.lwjgl.vulkan.VkCommandBuffer
import org.lwjgl.vulkan.VkDevice
import org.lwjgl.vulkan.VkPhysicalDevice
import java.nio.file.Files

/**
 * FSR 1.0 Manager - v1.0.8
 *
 * 核心逻辑：
 * 1. swapchain 保持物理分辨率（不再修改）
 * 2. WindowFSRMixin 修改 getWidth()/getHeight() 返回 FSR 低分辨率
 * 3. mainRenderTarget 以 FSR 低分辨率渲染
 * 4. Minecraft 自动将低分辨率内容拉伸到物理分辨率 swapchain
 */
object FSR1Manager {

    // 当前 FSR 预设档位（默认关闭：进游戏为原生渲染，按 F8 或视频设置按钮开启）
    var currentPreset: FSR1Preset = FSR1Preset.OFF
        private set

    // 是否启用 FSR
    val enabled: Boolean
        get() = currentPreset != FSR1Preset.OFF

    // 标记是否已初始化
    @Volatile
    private var initialized = false

    // 标记是否需要重建
    @Volatile
    private var needsRebuild = false

    // 当前 swapchain 尺寸（物理分辨率）
    private var swapchainWidth = 0
    private var swapchainHeight = 0

    // 原始输出分辨率（用于超分档）
    private var originalWidth = 0
    private var originalHeight = 0

    // 持久化的 Command Pool
    private var commandPool: Long = 0L

    // 持久化的 Command Buffer
    private var commandBuffer: VkCommandBuffer? = null

    // Fence 用于 GPU 同步
    private var fence: Long = 0L

    // 保存 device 引用
    private var savedDevice: VkDevice? = null
    private var savedPhysicalDevice: VkPhysicalDevice? = null

    // 帧计数器
    private var frameCount = 0
    private var lastPrintTime = System.currentTimeMillis()

    // VK_IMAGE_LAYOUT_PRESENT_SRC_KHR
    private const val VK_IMAGE_LAYOUT_PRESENT_SRC_KHR = 1000001002

    // -------------------------------------------------------------------------
    // 档位持久化：config/metalfxhelper.json
    // -------------------------------------------------------------------------

    private val configFile = FabricLoader.getInstance().getConfigDir().resolve("metalfxhelper.json")
    private val gson = Gson()

    /** 是否有待应用的启动恢复档位 */
    @Volatile
    private var pendingApply = false

    /**
     * 从配置文件加载上次保存的档位（仅设置状态；分辨率修改延迟到游戏循环
     * 开始后由 applyPendingPreset() 应用，此时 Window 与 surface 才就绪）
     */
    fun loadConfig() {
        try {
            if (!Files.exists(configFile)) {
                println("[FSR1Manager] 配置文件不存在，使用默认档位: ${currentPreset.displayName}")
                return
            }
            val obj = gson.fromJson(Files.readString(configFile), JsonObject::class.java)
            val saved = obj?.get("preset")?.asString ?: return
            val preset = FSR1Preset.fromString(saved)
            if (preset != currentPreset) {
                currentPreset = preset
                pendingApply = true
                println("[FSR1Manager] 已从配置恢复档位: ${preset.displayName}（将在游戏循环开始后应用）")
            }
        } catch (e: Exception) {
            println("[FSR1Manager] ⚠️ 配置加载失败: ${e.message}，使用默认档位")
        }
    }

    /** 保存当前档位到配置文件 */
    private fun saveConfig() {
        try {
            Files.createDirectories(configFile.parent)
            val obj = JsonObject()
            obj.addProperty("preset", currentPreset.name)
            Files.writeString(configFile, gson.toJson(obj))
        } catch (e: Exception) {
            println("[FSR1Manager] ⚠️ 配置保存失败: ${e.message}")
        }
    }

    /**
     * 游戏循环开始后每个 client tick 调用：应用启动时恢复的档位（只执行一次）。
     * OFF 无需应用（默认就是原生渲染路径）。
     */
    fun applyPendingPreset() {
        if (!pendingApply) return
        pendingApply = false
        if (currentPreset == FSR1Preset.OFF) return

        println("[FSR1Manager] 应用启动恢复的预设: ${currentPreset.displayName}")
        needsRebuild = true
        updateWindowFSRResolution(currentPreset)

        try {
            val mc = net.minecraft.client.Minecraft.getInstance()
            mc.invalidateSurfaceConfiguration()
            mc.resizeGui()
            println("[FSR1Manager] 已标记 surface 需要重新配置")
        } catch (e: Exception) {
            println("[FSR1Manager] 应用恢复预设失败: ${e.message}")
        }
    }

    /**
     * 切换到下一个 FSR 预设档位
     */
    fun cyclePreset(): FSR1Preset {
        val values = FSR1Preset.values()
        val nextIndex = (currentPreset.ordinal + 1) % values.size
        setPreset(values[nextIndex])
        return currentPreset
    }

    /**
     * 设置 FSR 预设档位
     */
    fun setPreset(preset: FSR1Preset) {
        if (preset == currentPreset) {
            println("[FSR1Manager] 尝试切换到相同档位: ${preset.displayName}，忽略")
            return
        }

        println("[FSR1Manager] ===== 切换预设 =====")
        println("[FSR1Manager]   从: ${currentPreset.displayName} (scale=${currentPreset.renderScale})")
        println("[FSR1Manager]   到: ${preset.displayName} (scale=${preset.renderScale})")

        // 保存当前的 swapchain 尺寸作为原始分辨率
        if (originalWidth == 0 || originalHeight == 0 || currentPreset == FSR1Preset.OFF || currentPreset == FSR1Preset.UPSCALED) {
            if (swapchainWidth > 0 && swapchainHeight > 0) {
                originalWidth = swapchainWidth
                originalHeight = swapchainHeight
                println("[FSR1Manager]   保存原始分辨率: ${originalWidth}x${originalHeight}")
            }
        }

        currentPreset = preset
        needsRebuild = true

        // 更新 WindowFSRMixin 的分辨率
        updateWindowFSRResolution(preset)

        // 标记 surface 需要重新配置
        try {
            val mc = net.minecraft.client.Minecraft.getInstance()
            mc.invalidateSurfaceConfiguration()
            mc.resizeGui()
            println("[FSR1Manager] 已标记 surface 需要重新配置")
        } catch (e: Exception) {
            println("[FSR1Manager] invalidateSurfaceConfiguration 失败: ${e.message}")
        }

        // 持久化当前档位，重启游戏后自动恢复
        saveConfig()
    }

    /**
     * 更新 WindowFSRMixin 的 FSR 分辨率
     */
    private fun updateWindowFSRResolution(preset: FSR1Preset) {
        try {
            val mc = net.minecraft.client.Minecraft.getInstance()
            val window = mc.window

            // 使用反射获取物理分辨率（通过 WindowFSRMixin 的方法）
            val getPhysWidth = window.javaClass.getMethod("metalfxhelper\$getPhysicalWidth")
            val getPhysHeight = window.javaClass.getMethod("metalfxhelper\$getPhysicalHeight")
            val physWidth = getPhysWidth.invoke(window) as Int
            val physHeight = getPhysHeight.invoke(window) as Int

            val (fsrWidth, fsrHeight, active) = if (preset == FSR1Preset.OFF || preset == FSR1Preset.UPSCALED) {
                // 关闭或超分档：使用物理分辨率
                Triple(physWidth, physHeight, false)
            } else {
                // 其他档位：计算 FSR 低分辨率
                val scale = preset.renderScale
                val rawW = (physWidth * scale).toInt()
                val rawH = (physHeight * scale).toInt()
                val w = Math.max(2, rawW - (rawW % 2))
                val h = Math.max(2, rawH - (rawH % 2))
                Triple(w, h, true)
            }

            // 使用反射调用 WindowFSRMixin 的方法
            val method = window.javaClass.getMethod("metalfxhelper\$updateFSRResolution", Int::class.java, Int::class.java, Boolean::class.java)
            method.invoke(window, fsrWidth, fsrHeight, active)

            if (active) {
                println("[FSR1Manager] WindowFSRMixin 更新: FSR 分辨率 ${fsrWidth}x${fsrHeight} (物理: ${physWidth}x${physHeight})")
            } else {
                println("[FSR1Manager] WindowFSRMixin 更新: FSR 关闭，使用物理分辨率 ${physWidth}x${physHeight}")
            }
        } catch (e: Exception) {
            println("[FSR1Manager] 更新 WindowFSRMixin 失败: ${e.message}")
            e.printStackTrace()
        }
    }

    /**
     * 设置原始分辨率
     */
    fun setOriginalResolution(width: Int, height: Int) {
        if (originalWidth == 0 || originalHeight == 0) {
            originalWidth = width
            originalHeight = height
            println("[FSR1Manager] 原始分辨率已设置: ${width}x${height}")
        }
    }

    /**
     * 由 VulkanBackendCreateDeviceMixin 调用，保存 VkPhysicalDevice
     */
    /**
     * 获取保存的 VkPhysicalDevice
     */
    fun getPhysicalDevice(): VkPhysicalDevice? {
        return savedPhysicalDevice
    }

    /**
     * 由 VulkanBackendCreateDeviceMixin 调用，保存 VkPhysicalDevice
     */
    fun setPhysicalDevice(physicalDevice: VkPhysicalDevice) {
        savedPhysicalDevice = physicalDevice
        println("[FSR1Manager] VkPhysicalDevice saved: 0x${physicalDevice.address().toString(16)}")
    }

    /**
     * 在 present() 前调用 - 使用实际的 swapchain 尺寸
     */
    fun onPresent(
        device: VulkanDevice,
        swapchainImages: it.unimi.dsi.fastutil.longs.LongList,
        currentImageIndex: Int,
        actualSwapchainWidth: Int,
        actualSwapchainHeight: Int
    ) {
        if (!enabled) return
        if (currentImageIndex < 0 || currentImageIndex >= swapchainImages.size) return

        val vkDevice = device.vkDevice()

        try {
            // 检查是否需要重建（档位切换后或分辨率变化）
            if (needsRebuild || !initialized ||
                actualSwapchainWidth != swapchainWidth ||
                actualSwapchainHeight != swapchainHeight) {

                if (actualSwapchainWidth != swapchainWidth || actualSwapchainHeight != swapchainHeight) {
                    println("[FSR1Manager] 检测到分辨率变化: ${swapchainWidth}x${swapchainHeight} -> ${actualSwapchainWidth}x${actualSwapchainHeight}")
                }

                needsRebuild = false
                initPipeline(device, actualSwapchainWidth, actualSwapchainHeight)
            }

            // 性能统计
            frameCount++
            val now = System.currentTimeMillis()
            if (now - lastPrintTime >= 5000) {
                val fps = frameCount / 5
                println("[FSR1Manager] 过去5秒处理了 ${frameCount} 帧 (~${fps} FPS)")
                frameCount = 0
                lastPrintTime = now
            }

        } catch (e: Exception) {
            println("[FSR1Manager] onPresent error: ${e.message}")
            e.printStackTrace()
            currentPreset = FSR1Preset.OFF
            needsRebuild = true
        }
    }

    /**
     * 初始化 FSR Pipeline
     */
    private fun initPipeline(
        device: VulkanDevice,
        actualWidth: Int,
        actualHeight: Int
    ) {
        println("[FSR1Manager] ===== 初始化 Pipeline =====")

        initialized = true

        try {
            swapchainWidth = actualWidth.coerceAtLeast(1)
            swapchainHeight = actualHeight.coerceAtLeast(1)

            println("[FSR1Manager]   Preset: ${currentPreset.displayName}")
            println("[FSR1Manager]   Swapchain (物理): ${swapchainWidth}x${swapchainHeight}")
            println("[FSR1Manager]   Render scale: ${currentPreset.renderScale}")

            val vkDevice = device.vkDevice()
            savedDevice = vkDevice

            // 创建持久化资源
            createPersistentResources(vkDevice)

            println("[FSR1Manager] Pipeline 初始化成功（低分辨率渲染模式）")

        } catch (e: Exception) {
            println("[FSR1Manager] initPipeline 失败: ${e.message}")
            e.printStackTrace()
            initialized = false
        }
    }

    /**
     * 创建持久化资源（Command Pool, Command Buffer, Fence）
     */
    private fun createPersistentResources(vkDevice: VkDevice) {
        // 创建 Command Pool
        if (commandPool == 0L) {
            MemoryStack.stackPush().use { stack ->
                val poolInfo = org.lwjgl.vulkan.VkCommandPoolCreateInfo.calloc(stack)
                    .sType(VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO)
                    .queueFamilyIndex(0)
                    .flags(VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT)

                val pPool = stack.callocLong(1)
                vkCheck(vkCreateCommandPool(vkDevice, poolInfo, null, pPool))
                commandPool = pPool.get(0)
                println("[FSR1Manager] Command Pool 创建: 0x${commandPool.toString(16)}")
            }
        }

        // 分配 Command Buffer
        if (commandBuffer == null && commandPool != 0L) {
            MemoryStack.stackPush().use { stack ->
                val allocInfo = org.lwjgl.vulkan.VkCommandBufferAllocateInfo.calloc(stack)
                    .sType(VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO)
                    .commandPool(commandPool)
                    .level(VK_COMMAND_BUFFER_LEVEL_PRIMARY)
                    .commandBufferCount(1)

                val pCmdBuf = stack.callocPointer(1)
                vkCheck(vkAllocateCommandBuffers(vkDevice, allocInfo, pCmdBuf))
                commandBuffer = VkCommandBuffer(pCmdBuf.get(0), vkDevice)
                println("[FSR1Manager] Command Buffer 分配成功")
            }
        }

        // 创建 Fence（初始状态为 signaled）
        if (fence == 0L) {
            MemoryStack.stackPush().use { stack ->
                val fenceInfo = org.lwjgl.vulkan.VkFenceCreateInfo.calloc(stack)
                    .sType(VK_STRUCTURE_TYPE_FENCE_CREATE_INFO)
                    .flags(VK_FENCE_CREATE_SIGNALED_BIT)

                val pFence = stack.callocLong(1)
                vkCheck(vkCreateFence(vkDevice, fenceInfo, null, pFence))
                fence = pFence.get(0)
                println("[FSR1Manager] Fence 创建（初始 signaled）")
            }
        }
    }

    /**
     * 完全清理所有资源（mod 卸载时调用）
     */
    fun cleanup() {
        savedDevice?.let { vkDevice ->
            // 等待 GPU
            if (fence != 0L) {
                vkWaitForFences(vkDevice, fence, true, 1000000000)
            }

            if (fence != 0L) {
                vkDestroyFence(vkDevice, fence, null)
                fence = 0L
            }

            commandBuffer?.let { cmdBuf ->
                vkFreeCommandBuffers(vkDevice, commandPool, cmdBuf)
                commandBuffer = null
            }

            if (commandPool != 0L) {
                vkDestroyCommandPool(vkDevice, commandPool, null)
                commandPool = 0L
            }
        }

        savedDevice = null
        savedPhysicalDevice = null

        initialized = false
        needsRebuild = false
        frameCount = 0
        originalWidth = 0
        originalHeight = 0
    }

    private fun vkCheck(result: Int) {
        if (result != VK_SUCCESS) {
            throw RuntimeException("Vulkan error: $result")
        }
    }
}
