package metalfxhelper.modid.client

/**
 * FSR 1.0 EASU + RCAS single-pass compute shader for Vulkan.
 *
 * Based on AMD FidelityFX Super Resolution 1.0 (EASU upscaling + RCAS sharpening)
 * adapted for a single compute pass using Vulkan storage images.
 */
object FSR1Shader {

    const val COMPUTE_SHADER_GLSL = """
#version 450

// =============================================================================
// AMD FidelityFX Super Resolution 1.0 — Single-Pass Compute (EASU + RCAS)
// =============================================================================
// This shader combines EASU (Edge-Adaptive Spatial Upsampling) and
// RCAS (Robust Contrast-Adaptive Sharpening) into one compute dispatch.
//
// Input : low-resolution  image (rgba8, readonly )
// Output: high-resolution image (rgba8, writeonly)
//
// Workgroup size: 16 x 16 x 1
// =============================================================================

layout(local_size_x = 16, local_size_y = 16, local_size_z = 1) in;

// ---------------------------------------------------------------------------
// Storage images (no samplers — direct load/store)
// ---------------------------------------------------------------------------
layout(set = 0, binding = 0, rgba8) uniform readonly  image2D inputImage;
layout(set = 0, binding = 1, rgba8) uniform writeonly image2D outputImage;

// ---------------------------------------------------------------------------
// Push constants: input/output dimensions
// ---------------------------------------------------------------------------
layout(push_constant) uniform PushConstants {
    uvec2 inputSize;   // low-res dimensions
    uvec2 outputSize;  // high-res dimensions
    float sharpness;   // RCAS sharpness (0.0 = off, 1.0 = full, typical 0.25)
} pc;

// ---------------------------------------------------------------------------
// Helper: sRGB <-> linear approximations (fast path)
// ---------------------------------------------------------------------------
vec3 toLinear(vec3 c) {
    return c * c;                 // cheap gamma-2 approximation
}

vec3 toSrgb(vec3 c) {
    return sqrt(max(c, vec3(0.0)));
}

// ---------------------------------------------------------------------------
// EASU helpers
// ---------------------------------------------------------------------------

// Lanczos-like filter (2-lobe)
float easuFilter(float x) {
    const float PI = 3.141592653589793;
    float a = 2.0; // lanczos2
    float v = x * PI;
    if (abs(v) < 1e-5) return 1.0;
    if (abs(v) > a * PI) return 0.0;
    return a * sin(v) * sin(v / a) / (v * v);
}

// Sample input image at integer pixel position (clamp to border)
vec4 sampleInput(ivec2 pos) {
    pos = clamp(pos, ivec2(0), ivec2(pc.inputSize) - ivec2(1));
    return imageLoad(inputImage, pos);
}

// ---------------------------------------------------------------------------
// EASU: Edge-Adaptive Spatial Upsampling
// ---------------------------------------------------------------------------
vec4 easu(ivec2 dstPos) {
    // Normalised destination UV in input space
    vec2 srcPos = (vec2(dstPos) + 0.5) * vec2(pc.inputSize) / vec2(pc.outputSize) - 0.5;
    ivec2 base = ivec2(floor(srcPos));
    vec2 frac = fract(srcPos);

    // Gather 4x4 neighbourhood
    vec4 c00 = sampleInput(base + ivec2(-1, -1));
    vec4 c10 = sampleInput(base + ivec2( 0, -1));
    vec4 c20 = sampleInput(base + ivec2( 1, -1));
    vec4 c30 = sampleInput(base + ivec2( 2, -1));

    vec4 c01 = sampleInput(base + ivec2(-1, 0));
    vec4 c11 = sampleInput(base + ivec2( 0, 0));
    vec4 c21 = sampleInput(base + ivec2( 1, 0));
    vec4 c31 = sampleInput(base + ivec2( 2, 0));

    vec4 c02 = sampleInput(base + ivec2(-1, 1));
    vec4 c12 = sampleInput(base + ivec2( 0, 1));
    vec4 c22 = sampleInput(base + ivec2( 1, 1));
    vec4 c32 = sampleInput(base + ivec2( 2, 1));

    vec4 c03 = sampleInput(base + ivec2(-1, 2));
    vec4 c13 = sampleInput(base + ivec2( 0, 2));
    vec4 c23 = sampleInput(base + ivec2( 1, 2));
    vec4 c33 = sampleInput(base + ivec2( 2, 2));

    // Luminance (Rec.709) for edge detection
    float l00 = dot(c00.rgb, vec3(0.2126, 0.7152, 0.0722));
    float l10 = dot(c10.rgb, vec3(0.2126, 0.7152, 0.0722));
    float l20 = dot(c20.rgb, vec3(0.2126, 0.7152, 0.0722));
    float l30 = dot(c30.rgb, vec3(0.2126, 0.7152, 0.0722));

    float l01 = dot(c01.rgb, vec3(0.2126, 0.7152, 0.0722));
    float l11 = dot(c11.rgb, vec3(0.2126, 0.7152, 0.0722));
    float l21 = dot(c21.rgb, vec3(0.2126, 0.7152, 0.0722));
    float l31 = dot(c31.rgb, vec3(0.2126, 0.7152, 0.0722));

    float l02 = dot(c02.rgb, vec3(0.2126, 0.7152, 0.0722));
    float l12 = dot(c12.rgb, vec3(0.2126, 0.7152, 0.0722));
    float l22 = dot(c22.rgb, vec3(0.2126, 0.7152, 0.0722));
    float l32 = dot(c32.rgb, vec3(0.2126, 0.7152, 0.0722));

    float l03 = dot(c03.rgb, vec3(0.2126, 0.7152, 0.0722));
    float l13 = dot(c13.rgb, vec3(0.2126, 0.7152, 0.0722));
    float l23 = dot(c23.rgb, vec3(0.2126, 0.7152, 0.0722));
    float l33 = dot(c33.rgb, vec3(0.2126, 0.7152, 0.0722));

    // Edge detection (Sobel-like gradients)
    float gradX =
        -1.0 * l00 + 1.0 * l20 +
        -2.0 * l01 + 2.0 * l21 +
        -1.0 * l02 + 1.0 * l22;

    float gradY =
        -1.0 * l00 - 2.0 * l10 - 1.0 * l20 +
         1.0 * l02 + 2.0 * l12 + 1.0 * l22;

    float edgeStrength = length(vec2(gradX, gradY));

    // Normalise edge to a soft blend factor (0 = smooth, 1 = edge)
    float edgeFactor = clamp(edgeStrength * 2.0, 0.0, 1.0);

    // Bicubic / Lanczos weights
    float wx0 = easuFilter(frac.x + 1.0);
    float wx1 = easuFilter(frac.x + 0.0);
    float wx2 = easuFilter(frac.x - 1.0);
    float wx3 = easuFilter(frac.x - 2.0);

    float wy0 = easuFilter(frac.y + 1.0);
    float wy1 = easuFilter(frac.y + 0.0);
    float wy2 = easuFilter(frac.y - 1.0);
    float wy3 = easuFilter(frac.y - 2.0);

    float wSum = 0.0;
    vec3 colour = vec3(0.0);
    float alpha = 0.0;

    // Row 0
    float w = wx0 * wy0; colour += c00.rgb * w; alpha += c00.a * w; wSum += w;
    w = wx1 * wy0;       colour += c10.rgb * w; alpha += c10.a * w; wSum += w;
    w = wx2 * wy0;       colour += c20.rgb * w; alpha += c20.a * w; wSum += w;
    w = wx3 * wy0;       colour += c30.rgb * w; alpha += c30.a * w; wSum += w;

    // Row 1
    w = wx0 * wy1;       colour += c01.rgb * w; alpha += c01.a * w; wSum += w;
    w = wx1 * wy1;       colour += c11.rgb * w; alpha += c11.a * w; wSum += w;
    w = wx2 * wy1;       colour += c21.rgb * w; alpha += c21.a * w; wSum += w;
    w = wx3 * wy1;       colour += c31.rgb * w; alpha += c31.a * w; wSum += w;

    // Row 2
    w = wx0 * wy2;       colour += c02.rgb * w; alpha += c02.a * w; wSum += w;
    w = wx1 * wy2;       colour += c12.rgb * w; alpha += c12.a * w; wSum += w;
    w = wx2 * wy2;       colour += c22.rgb * w; alpha += c22.a * w; wSum += w;
    w = wx3 * wy2;       colour += c32.rgb * w; alpha += c32.a * w; wSum += w;

    // Row 3
    w = wx0 * wy3;       colour += c03.rgb * w; alpha += c03.a * w; wSum += w;
    w = wx1 * wy3;       colour += c13.rgb * w; alpha += c13.a * w; wSum += w;
    w = wx2 * wy3;       colour += c23.rgb * w; alpha += c23.a * w; wSum += w;
    w = wx3 * wy3;       colour += c33.rgb * w; alpha += c33.a * w; wSum += w;

    colour /= wSum;
    alpha  /= wSum;

    // Edge-aware blending: near edges bias toward sharper Lanczos,
    // away from edges allow slightly softer result (already implicit
    // in the lanczos2 window). Here we just pass through.
    return vec4(colour, alpha);
}

// ---------------------------------------------------------------------------
// RCAS: Robust Contrast-Adaptive Sharpening
// ---------------------------------------------------------------------------
vec4 rcas(ivec2 pos, vec4 centre) {
    // Sample cross neighbours in OUTPUT space (already upscaled)
    // We read from the EASU result computed above; since this is a single
    // compute pass we cannot sample neighbours that haven't been written yet.
    // Instead we approximate RCAS by operating on the EASU result directly
    // using a kernel that only needs the centre and its 4 cross neighbours.
    //
    // For a true two-pass approach you would write EASU to an intermediate
    // image and run RCAS in a second pass. Here we fuse them by applying
    // RCAS on the EASU-generated colour using the same 4-tap cross pattern
    // but reading from the input image at the corresponding high-res grid.
    // Because the high-res grid is denser, we approximate by reading the
    // nearest low-res pixels and interpolating.
    //
    // SIMPLIFICATION: we apply a lightweight unsharp-mask style sharpening
    // using the 4 direct neighbours in the upscaled domain, estimated from
    // the input image via bilinear reconstruction.

    vec2 srcPos = (vec2(pos) + 0.5) * vec2(pc.inputSize) / vec2(pc.outputSize) - 0.5;
    vec2 texel = 1.0 / vec2(pc.inputSize);

    // Neighbour offsets in source space (one output pixel step)
    vec2 off = vec2(1.0) / vec2(pc.outputSize) * vec2(pc.inputSize);

    vec4 n = sampleInput(ivec2(round(srcPos + vec2( 0.0, -off.y))));
    vec4 s = sampleInput(ivec2(round(srcPos + vec2( 0.0,  off.y))));
    vec4 e = sampleInput(ivec2(round(srcPos + vec2( off.x,  0.0))));
    vec4 w = sampleInput(ivec2(round(srcPos + vec2(-off.x,  0.0))));

    // Luma neighbours
    float nl = dot(n.rgb, vec3(0.2126, 0.7152, 0.0722));
    float sl = dot(s.rgb, vec3(0.2126, 0.7152, 0.0722));
    float el = dot(e.rgb, vec3(0.2126, 0.7152, 0.0722));
    float wl = dot(w.rgb, vec3(0.2126, 0.7152, 0.0722));
    float cl = dot(centre.rgb, vec3(0.2126, 0.7152, 0.0722));

    // Local contrast (min / max of cross)
    float minL = min(cl, min(min(nl, sl), min(el, wl)));
    float maxL = max(cl, max(max(nl, sl), max(el, wl)));
    float contrast = maxL - minL;

    // RCAS attenuation: reduce sharpening in low-contrast areas (noise guard)
    float peak = 1.0 - pc.sharpness;
    float amp = 1.0 / (2.0 * peak + 1e-5);
    float attenuation = clamp(contrast * amp, 0.0, 1.0);

    // Sharpen kernel: 4 neighbours, centre negative
    vec3 sharpened = centre.rgb * (1.0 + 4.0 * pc.sharpness * attenuation)
                   - (n.rgb + s.rgb + e.rgb + w.rgb) * (pc.sharpness * attenuation);

    // Clamp to prevent ringing
    vec3 minC = min(centre.rgb, min(min(n.rgb, s.rgb), min(e.rgb, w.rgb)));
    vec3 maxC = max(centre.rgb, max(max(n.rgb, s.rgb), max(e.rgb, w.rgb)));
    sharpened = clamp(sharpened, minC, maxC);

    return vec4(sharpened, centre.a);
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------
void main() {
    ivec2 dstPos = ivec2(gl_GlobalInvocationID.xy);

    // Guard against out-of-bounds work items
    if (any(greaterThanEqual(dstPos, ivec2(pc.outputSize)))) {
        return;
    }

    // 1. EASU upscaling
    vec4 upscaled = easu(dstPos);

    // 2. RCAS sharpening (fused in same pass)
    vec4 finalColour = rcas(dstPos, upscaled);

    // Store result
    imageStore(outputImage, dstPos, clamp(finalColour, 0.0, 1.0));
}
"""

    /**
     * Returns the GLSL source as a null-terminated UTF-8 byte array suitable
     * for passing to Vulkan shader compilation (e.g. glslang or shaderc).
     */
    fun sourceBytes(): ByteArray = COMPUTE_SHADER_GLSL.toByteArray(Charsets.UTF_8)

    /**
     * Push constant layout expected by the shader.
     *
     * @property inputSize   Low-resolution width/height in pixels
     * @property outputSize  High-resolution width/height in pixels
     * @property sharpness   RCAS sharpness factor (0.0 … 1.0, typical 0.25)
     */
    data class PushConstants(
        val inputSize: Pair<UInt, UInt>,
        val outputSize: Pair<UInt, UInt>,
        val sharpness: Float
    ) {
        companion object {
            /** Size in bytes: 2×uvec2 + 1×float = 4×4 + 4 = 20 bytes (padded to 24 by driver usually) */
            const val SIZE = 20
        }

        fun toByteArray(): ByteArray {
            val buf = java.nio.ByteBuffer.allocate(SIZE)
            buf.order(java.nio.ByteOrder.LITTLE_ENDIAN)
            buf.putInt(inputSize.first.toInt())
            buf.putInt(inputSize.second.toInt())
            buf.putInt(outputSize.first.toInt())
            buf.putInt(outputSize.second.toInt())
            buf.putFloat(sharpness)
            return buf.array()
        }
    }
}
