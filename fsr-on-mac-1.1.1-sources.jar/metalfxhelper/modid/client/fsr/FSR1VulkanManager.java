package metalfxhelper.modid.client.fsr;

import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vulkan.VulkanDevice;
import com.mojang.blaze3d.vulkan.VulkanGpuTextureView;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.*;

import java.lang.reflect.Field;
import java.nio.LongBuffer;

import static org.lwjgl.vulkan.VK10.*;

/**
 * FSR 1.0 Vulkan 管理器：持有 JNI 上下文、全分辨率离屏纹理，负责 EASU+RCAS 分发。
 *
 * 架构（v1.1.0，修复画面倒置 + 闪烁黑屏）：
 *   JNI dispatch 不再直写 swapchain image（swapchain usage 只有 TRANSFER_DST，
 *   当 storage 写是 usage 违规；且 compute 写入与 present semaphore 的 TRANSFER
 *   阶段不匹配造成竞争黑屏；EASU 无 Y 翻转导致画面倒置）。
 *   改为：dispatch 写入 mod 自有的离屏纹理（usage = STORAGE | TRANSFER_SRC，
 *   满足 JNI 的 GENERAL 契约），随后由 VulkanGpuSurfaceBlitMixin 用与原版逐字节
 *   一致的 transfer blit（含 Y 翻转）拷入 swapchain。
 *
 * 布局契约（与 src/fsr1_jni.h 一致）：dispatch 时 src 与 dst image 都必须处于
 * VK_IMAGE_LAYOUT_GENERAL；dispatch 结束后 dst 仍处于 GENERAL。
 * 离屏纹理每帧的布局流转由调用方负责：
 *   GENERAL（dispatch 写）→ TRANSFER_SRC_OPTIMAL（blit 读）→ GENERAL（下一帧）。
 */
public class FSR1VulkanManager {

    private static FSR1VulkanManager INSTANCE;

    private long fsrCtx = 0;
    private boolean initialized = false;
    private int frameIndex = 0;
    private VkDevice vkDevice;
    private VkPhysicalDevice vkPhysicalDevice;
    private float sharpness = 0.25f;
    private boolean enabled = false;

    /** 创建 ctx 时使用的输出格式（= 真实 swapchain 格式，0 表示原生侧默认 B8G8R8A8_UNORM） */
    private int outputFormat = 0;

    /** 全分辨率离屏纹理：EASU+RCAS 的输出目标 */
    private long offscreenImage = 0;
    private long offscreenMemory = 0;
    private long offscreenView = 0;
    private int offscreenW = -1;
    private int offscreenH = -1;

    private FSR1VulkanManager() {}

    public static FSR1VulkanManager getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new FSR1VulkanManager();
        }
        return INSTANCE;
    }

    /** JNI 上下文是否可用（不依赖历史遗留的 enabled 标志） */
    public boolean isReady() {
        return initialized && fsrCtx != 0;
    }

    /** 兼容旧调用：输出格式用原生侧默认值（B8G8R8A8_UNORM） */
    public void initialize(GpuDevice device, VkPhysicalDevice physicalDevice) {
        initialize(device, physicalDevice, 0);
    }

    /**
     * 创建 JNI FSR 上下文。
     *
     * @param outputFormat swapchain image 的真实 VkFormat（VulkanGpuSurface.swapchainImageFormat），
     *                     传 0 使用原生侧默认 B8G8R8A8_UNORM
     */
    public void initialize(GpuDevice device, VkPhysicalDevice physicalDevice, int outputFormat) {
        if (initialized) return;

        try {
            VulkanDevice vulkanDevice = getVulkanDevice(device);
            if (vulkanDevice == null) {
                System.out.println("[FSR1Manager] ❌ 无法获取 VulkanDevice");
                return;
            }

            this.vkDevice = vulkanDevice.vkDevice();
            this.vkPhysicalDevice = physicalDevice;
            this.outputFormat = outputFormat;

            System.out.println("[FSR1Manager] 初始化 FSR 上下文...");
            System.out.println("[FSR1Manager]   VkDevice: 0x" + Long.toHexString(vkDevice.address()));
            System.out.println("[FSR1Manager]   VkPhysicalDevice: 0x" + Long.toHexString(physicalDevice.address()));
            System.out.println("[FSR1Manager]   OutputFormat: " + outputFormat);

            fsrCtx = FSR1Vulkan.create(vkDevice.address(), physicalDevice.address(), outputFormat);

            if (fsrCtx == 0) {
                System.out.println("[FSR1Manager] ❌ FSR 上下文创建失败");
                return;
            }

            System.out.println("[FSR1Manager] ✅ FSR 上下文创建成功: 0x" + Long.toHexString(fsrCtx));
            initialized = true;

        } catch (Exception e) {
            System.out.println("[FSR1Manager] ❌ 初始化异常: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // -------------------------------------------------------------------------
    // 离屏纹理
    // -------------------------------------------------------------------------

    /**
     * 确保离屏纹理存在且尺寸为 w×h（= swapchain 物理尺寸）。
     *
     * @return 0 = 已存在可用；1 = 新建成功（调用方必须在 dispatch 前记录一次
     *         UNDEFINED→GENERAL 的 barrier）；负数 = 创建失败
     */
    public int ensureOffscreen(int w, int h, int format) {
        if (!isReady()) return -1;
        if (offscreenImage != 0 && offscreenW == w && offscreenH == h) return 0;

        destroyOffscreen();

        if (format == 0) {
            format = VK_FORMAT_B8G8R8A8_UNORM;
        }

        try (MemoryStack stack = MemoryStack.stackPush()) {
            // ---- 创建 image（STORAGE 供 compute 写入，TRANSFER_SRC 供 blit 读取） ----
            VkImageCreateInfo imageInfo = VkImageCreateInfo.calloc(stack)
                    .sType(VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO)
                    .imageType(VK_IMAGE_TYPE_2D)
                    .format(format)
                    .mipLevels(1)
                    .arrayLayers(1)
                    .samples(VK_SAMPLE_COUNT_1_BIT)
                    .tiling(VK_IMAGE_TILING_OPTIMAL)
                    .usage(VK_IMAGE_USAGE_STORAGE_BIT | VK_IMAGE_USAGE_TRANSFER_SRC_BIT)
                    .sharingMode(VK_SHARING_MODE_EXCLUSIVE)
                    .initialLayout(VK_IMAGE_LAYOUT_UNDEFINED);
            imageInfo.extent().width(w).height(h).depth(1);

            LongBuffer pImage = stack.mallocLong(1);
            int createResult = vkCreateImage(vkDevice, imageInfo, null, pImage);
            if (createResult != VK_SUCCESS) {
                System.out.println("[FSR1Manager] ❌ vkCreateImage 失败: " + createResult);
                return -1;
            }
            offscreenImage = pImage.get(0);

            // ---- 分配并绑定显存 ----
            VkMemoryRequirements memReqs = VkMemoryRequirements.calloc(stack);
            vkGetImageMemoryRequirements(vkDevice, offscreenImage, memReqs);

            VkPhysicalDeviceMemoryProperties memProps = VkPhysicalDeviceMemoryProperties.calloc(stack);
            vkGetPhysicalDeviceMemoryProperties(vkPhysicalDevice, memProps);

            int typeIndex = -1;
            for (int i = 0; i < memProps.memoryTypeCount(); i++) {
                if ((memReqs.memoryTypeBits() & (1 << i)) != 0 &&
                    (memProps.memoryTypes(i).propertyFlags() & VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT) != 0) {
                    typeIndex = i;
                    break;
                }
            }
            if (typeIndex < 0) {
                System.out.println("[FSR1Manager] ❌ 找不到 DEVICE_LOCAL 显存类型");
                destroyOffscreen();
                return -1;
            }

            VkMemoryAllocateInfo allocInfo = VkMemoryAllocateInfo.calloc(stack)
                    .sType(VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO)
                    .allocationSize(memReqs.size())
                    .memoryTypeIndex(typeIndex);
            LongBuffer pMem = stack.mallocLong(1);
            int allocResult = vkAllocateMemory(vkDevice, allocInfo, null, pMem);
            if (allocResult != VK_SUCCESS) {
                System.out.println("[FSR1Manager] ❌ vkAllocateMemory 失败: " + allocResult);
                destroyOffscreen();
                return -1;
            }
            offscreenMemory = pMem.get(0);
            vkBindImageMemory(vkDevice, offscreenImage, offscreenMemory, 0);

            // ---- 创建 view ----
            long view = createImageView2D(offscreenImage, format);
            if (view == 0) {
                destroyOffscreen();
                return -1;
            }
            offscreenView = view;

            offscreenW = w;
            offscreenH = h;
            System.out.println("[FSR1Manager] 离屏纹理已创建: " + w + "x" + h + ", format=" + format);
            return 1;

        } catch (Exception e) {
            System.out.println("[FSR1Manager] ❌ 离屏纹理创建异常: " + e.getMessage());
            e.printStackTrace();
            destroyOffscreen();
            return -1;
        }
    }

    /** 离屏纹理 image handle（供调用方做布局迁移）；0 = 未创建 */
    public long getOffscreenImage() {
        return offscreenImage;
    }

    /**
     * 执行一帧 FSR EASU+RCAS：src（低分辨率，须已处于 GENERAL）→ 离屏纹理
     * （须已处于 GENERAL，displayW×displayH），命令记录到给定的 commandBuffer。
     *
     * @return {@link FSR1Vulkan#OK} 或 FSR1Vulkan.ERROR_*；-1 表示 Java 侧前置条件不满足
     */
    public int dispatchToOffscreen(GpuTextureView srcTextureView,
                                   int renderW, int renderH,
                                   int displayW, int displayH,
                                   long commandBufferHandle) {
        if (!isReady() || offscreenView == 0) return -1;

        long srcViewHandle = getVkImageView(srcTextureView);
        if (srcViewHandle == 0) {
            System.out.println("[FSR1Manager] ❌ 无法获取 srcImageView");
            return -1;
        }

        int result = FSR1Vulkan.dispatch(
                fsrCtx,
                srcViewHandle,
                offscreenView,
                renderW, renderH,
                displayW, displayH,
                sharpness,
                commandBufferHandle
        );

        if (result == FSR1Vulkan.OK) {
            frameIndex++;
        }
        return result;
    }

    private long createImageView2D(long image, int format) {
        try (MemoryStack stack = MemoryStack.stackPush()) {
            VkImageViewCreateInfo createInfo = VkImageViewCreateInfo.calloc(stack)
                    .sType(VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO)
                    .image(image)
                    .viewType(VK_IMAGE_VIEW_TYPE_2D)
                    .format(format)
                    .components(VkComponentMapping.calloc(stack)
                            .r(VK_COMPONENT_SWIZZLE_IDENTITY)
                            .g(VK_COMPONENT_SWIZZLE_IDENTITY)
                            .b(VK_COMPONENT_SWIZZLE_IDENTITY)
                            .a(VK_COMPONENT_SWIZZLE_IDENTITY))
                    .subresourceRange(VkImageSubresourceRange.calloc(stack)
                            .aspectMask(VK_IMAGE_ASPECT_COLOR_BIT)
                            .baseMipLevel(0)
                            .levelCount(1)
                            .baseArrayLayer(0)
                            .layerCount(1));

            long[] pView = new long[1];
            int result = vkCreateImageView(vkDevice, createInfo, null, pView);
            if (result != VK_SUCCESS) {
                System.out.println("[FSR1Manager] ❌ vkCreateImageView 失败: " + result + " (format=" + format + ")");
                return 0;
            }
            return pView[0];
        }
    }

    private void destroyOffscreen() {
        if (vkDevice == null) return;
        if (offscreenImage != 0 || offscreenMemory != 0 || offscreenView != 0) {
            // 离屏纹理可能正被在途命令使用，销毁前先等 GPU 空闲（仅发生在换档/改分辨率时）
            try {
                vkDeviceWaitIdle(vkDevice);
            } catch (Exception ignored) {
            }
        }
        if (offscreenView != 0) {
            vkDestroyImageView(vkDevice, offscreenView, null);
            offscreenView = 0;
        }
        if (offscreenImage != 0) {
            vkDestroyImage(vkDevice, offscreenImage, null);
            offscreenImage = 0;
        }
        if (offscreenMemory != 0) {
            vkFreeMemory(vkDevice, offscreenMemory, null);
            offscreenMemory = 0;
        }
        offscreenW = -1;
        offscreenH = -1;
    }

    private long getVkImageView(GpuTextureView textureView) {
        if (textureView instanceof VulkanGpuTextureView) {
            return ((VulkanGpuTextureView) textureView).vkImageView();
        }
        return 0;
    }

    // -------------------------------------------------------------------------
    // 以下为历史遗留代码（VulkanGpuSurfacePresentMixin 时代的 present()-HEAD 路径），
    // 已不再被调用，保留以便参考；dispatch 的实际入口是 dispatchToOffscreen()。
    // -------------------------------------------------------------------------

    @Deprecated
    public void upscale(
            GpuTextureView srcTextureView,
            long dstImageHandle,
            int renderW, int renderH,
            int displayW, int displayH,
            com.mojang.blaze3d.systems.CommandEncoder commandEncoder) {

        if (!initialized || fsrCtx == 0) {
            return;
        }

        try {
            long srcViewHandle = getVkImageView(srcTextureView);
            if (srcViewHandle == 0) {
                return;
            }

            long dstViewHandle = createImageView2D(dstImageHandle, VK_FORMAT_B8G8R8A8_UNORM);
            if (dstViewHandle == 0) {
                return;
            }

            long commandBufferHandle = getCommandBufferHandle(commandEncoder);
            if (commandBufferHandle == 0) {
                vkDestroyImageView(vkDevice, dstViewHandle, null);
                return;
            }

            int result = FSR1Vulkan.dispatch(
                    fsrCtx,
                    srcViewHandle,
                    dstViewHandle,
                    renderW, renderH,
                    displayW, displayH,
                    sharpness,
                    commandBufferHandle
            );

            if (result == FSR1Vulkan.OK) {
                frameIndex++;
            }

        } catch (Exception e) {
            System.out.println("[FSR1Manager] ❌ upscale 异常: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private long getCommandBufferHandle(com.mojang.blaze3d.systems.CommandEncoder commandEncoder) {
        try {
            Field backendField = commandEncoder.getClass().getDeclaredField("backend");
            backendField.setAccessible(true);
            Object backend = backendField.get(commandEncoder);

            if (backend instanceof com.mojang.blaze3d.vulkan.VulkanCommandEncoder) {
                com.mojang.blaze3d.vulkan.VulkanCommandEncoder vulkanEncoder =
                        (com.mojang.blaze3d.vulkan.VulkanCommandEncoder) backend;

                VkCommandBuffer cmdBuf = vulkanEncoder.allocateAndBeginTransientCommandBuffer();
                if (cmdBuf != null) {
                    return cmdBuf.address();
                }
            }
        } catch (Exception e) {
            System.out.println("[FSR1Manager] ❌ 获取 CommandBuffer 失败: " + e.getMessage());
        }
        return 0;
    }

    private VulkanDevice getVulkanDevice(GpuDevice device) {
        try {
            Field backendField = device.getClass().getDeclaredField("backend");
            backendField.setAccessible(true);
            Object backend = backendField.get(device);

            if (backend instanceof VulkanDevice) {
                return (VulkanDevice) backend;
            }
        } catch (Exception e) {
            System.out.println("[FSR1Manager] ❌ 获取 VulkanDevice 失败: " + e.getMessage());
        }
        return null;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public boolean isEnabled() {
        return enabled && initialized;
    }

    public void setSharpness(float sharpness) {
        this.sharpness = sharpness;
    }

    public void cleanup() {
        destroyOffscreen();

        if (fsrCtx != 0) {
            FSR1Vulkan.destroy(fsrCtx);
            fsrCtx = 0;
        }
        initialized = false;
        System.out.println("[FSR1Manager] FSR 上下文已销毁");
    }
}
