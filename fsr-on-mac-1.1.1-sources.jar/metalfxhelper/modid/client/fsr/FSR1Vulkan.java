package metalfxhelper.modid.client.fsr;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

/**
 * FSR 1.0 Vulkan JNI black box.
 *
 * This class loads the native {@code libfsr1vulkan.dylib} (macOS) /
 * {@code libfsr1vulkan.so} (Linux) / {@code fsr1vulkan.dll} (Windows) and
 * exposes three native entry points:
 *
 * <ul>
 *   <li>{@link #create(long, long, int)} – create a long-lived context</li>
 *   <li>{@link #dispatch(long, long, long, int, int, int, int, float, long)} –
 *       run one frame of EASU + RCAS</li>
 *   <li>{@link #destroy(long)} – tear down the context</li>
 * </ul>
 *
 * The native context internally owns:
 * <ul>
 *   <li>two compute pipelines (EASU and RCAS) compiled from AMD ffx_fsr1.h</li>
 *   <li>a {@code VkPipelineLayout} and {@code VkDescriptorSetLayout}</li>
 *   <li>a clamp-to-edge sampler</li>
 *   <li>an intermediate RGBA16F image for the EASU→RCAS hand-off</li>
 *   <li>a per-frame descriptor-set ring buffer</li>
 * </ul>
 *
 * Library loading order (first success wins):
 * <ol>
 *   <li>{@code java.library.path} via {@link System#loadLibrary(String)}</li>
 *   <li>classpath resource {@code /natives/<lib>} (bundled in the mod JAR from
 *       {@code src/client/resources/natives/}), extracted to a temp dir and
 *       loaded by absolute path — works both in dev and in the packaged JAR</li>
 *   <li>dev-environment fallback paths under {@code user.dir}</li>
 * </ol>
 */
public class FSR1Vulkan {

    private static final String LIB_BASE_NAME = "fsr1vulkan";

    static {
        boolean loaded = false;

        // 方法1: java.library.path（玩家自行放置或启动参数指定时的路径）
        try {
            System.loadLibrary(LIB_BASE_NAME);
            System.out.println("[FSR1Vulkan] ✅ 从 java.library.path 加载成功");
            loaded = true;
        } catch (UnsatisfiedLinkError e) {
            System.out.println("[FSR1Vulkan] ⚠️ java.library.path 中没有该库: " + e.getMessage());
        }

        // 方法2: 从 classpath（mod JAR 内的 /natives/ 资源）解压后加载 —— 发布版的标准路径
        if (!loaded) {
            loaded = loadFromClasspath();
        }

        // 方法3: 开发环境回退路径（runClient 时 user.dir 为项目下的 run/ 目录）
        if (!loaded) {
            String userDir = System.getProperty("user.dir");
            String fileName = nativeFileName();
            String[] candidates = {
                userDir + "/natives/" + fileName,
                userDir + "/run/natives/" + fileName,
                userDir + "/../run/natives/" + fileName,
                "/Users/weisiheng/Desktop/metalfxhelper-template-26.2/run/natives/" + fileName
            };

            for (String path : candidates) {
                try {
                    System.load(path);
                    System.out.println("[FSR1Vulkan] ✅ 从绝对路径加载成功: " + path);
                    loaded = true;
                    break;
                } catch (UnsatisfiedLinkError e) {
                    System.out.println("[FSR1Vulkan] ❌ 加载失败 (" + path + "): " + e.getMessage());
                }
            }
        }

        if (!loaded) {
            System.err.println("[FSR1Vulkan] ❌❌❌ 无法加载 " + nativeFileName() + "，FSR 功能将不可用");
            System.err.println("[FSR1Vulkan] java.library.path = " + System.getProperty("java.library.path"));
        }
    }

    /**
     * 平台相关的库文件名：macOS → {@code libfsr1vulkan.dylib}，
     * Windows → {@code fsr1vulkan.dll}，其他（Linux）→ {@code libfsr1vulkan.so}。
     */
    private static String nativeFileName() {
        String os = System.getProperty("os.name", "").toLowerCase();
        if (os.contains("mac")) {
            return "lib" + LIB_BASE_NAME + ".dylib";
        }
        if (os.contains("win")) {
            return LIB_BASE_NAME + ".dll";
        }
        return "lib" + LIB_BASE_NAME + ".so";
    }

    /**
     * 从 classpath 读取 {@code /natives/<lib>} 资源（开发时来自
     * {@code build/resources}，发布时来自 mod JAR 内部），解压到临时目录后
     * 用绝对路径加载。{@link System#load(String)} 无法直接读取 JAR 内文件，
     * 所以必须先落盘。
     *
     * @return {@code true} 加载成功
     */
    private static boolean loadFromClasspath() {
        String resourcePath = "/natives/" + nativeFileName();
        try (InputStream in = FSR1Vulkan.class.getResourceAsStream(resourcePath)) {
            if (in == null) {
                System.out.println("[FSR1Vulkan] ⚠️ classpath 中没有资源 " + resourcePath);
                return false;
            }

            Path tempDir = Files.createTempDirectory("fsr1vulkan-natives");
            Path tempLib = tempDir.resolve(nativeFileName());
            Files.copy(in, tempLib, StandardCopyOption.REPLACE_EXISTING);
            // 注意注册顺序：deleteOnExit 按注册的逆序执行，先删文件再删目录
            tempDir.toFile().deleteOnExit();
            tempLib.toFile().deleteOnExit();

            System.load(tempLib.toAbsolutePath().toString());
            System.out.println("[FSR1Vulkan] ✅ 从 JAR 资源解压并加载成功: " + tempLib);
            return true;
        } catch (IOException | UnsatisfiedLinkError e) {
            System.err.println("[FSR1Vulkan] ❌ 从 classpath 资源加载失败: " + e.getMessage());
            return false;
        }
    }

    // -------------------------------------------------------------------------
    // Return codes (mirror src/fsr1_jni.h).
    // -------------------------------------------------------------------------
    public static final int OK                           = 0;
    public static final int ERROR_INVALID_CONTEXT       = -1;
    public static final int ERROR_NO_DEVICE             = -2;
    public static final int ERROR_PIPELINE_CREATION     = -3;
    public static final int ERROR_OUT_OF_MEMORY         = -4;
    public static final int ERROR_SPIRV_LOAD            = -5;
    public static final int ERROR_BAD_DIMENSIONS        = -6;
    public static final int ERROR_DESCRIPTOR_POOL       = -7;

    // -------------------------------------------------------------------------
    // Native methods.
    // -------------------------------------------------------------------------

    /**
     * Create the native FSR 1.0 context.
     *
     * @param vkDevice       Vulkan logical device handle ({@code VkDevice})
     * @param vkPhysicalDevice Vulkan physical device handle ({@code VkPhysicalDevice})
     * @param outputFormat   Vulkan format of {@code dstImageView}. Pass 0 to use
     *                       the default {@code VK_FORMAT_B8G8R8A8_UNORM}.
     * @return opaque context pointer (store as a {@code long}), or 0 on failure
     */
    public static native long create(long vkDevice, long vkPhysicalDevice, int outputFormat);

    /**
     * Dispatch one frame of FSR 1.0 upscaling + sharpening.
     *
     * The source and destination images must both be in
     * {@code VK_IMAGE_LAYOUT_GENERAL} when this method is called. The method
     * leaves {@code dstImageView}'s image in {@code VK_IMAGE_LAYOUT_GENERAL}.
     *
     * @param ctx            context pointer returned by {@link #create}
     * @param srcImageView   low-resolution input {@code VkImageView}
     * @param dstImageView   high-resolution output {@code VkImageView}
     * @param renderW        low-resolution width
     * @param renderH        low-resolution height
     * @param displayW       high-resolution width
     * @param displayH       high-resolution height
     * @param sharpness      RCAS sharpness (0.0 = off, typical 0.25)
     * @param commandBuffer  {@code VkCommandBuffer} to record into
     * @return one of the {@code OK} / {@code ERROR_*} codes above
     */
    public static native int dispatch(
            long ctx,
            long srcImageView,
            long dstImageView,
            int renderW, int renderH,
            int displayW, int displayH,
            float sharpness,
            long commandBuffer);

    /**
     * Destroy the native context and all Vulkan objects it owns.
     *
     * @param ctx context pointer returned by {@link #create}
     */
    public static native void destroy(long ctx);
}
