package metalfxhelper.modid.client

/**
 * FSR 1.0 质量预设档位
 *
 * 每个档位定义了实际渲染分辨率与输出分辨率的比例：
 * - OFF:         禁用 FSR，使用原生分辨率渲染
 * - PERFORMANCE: 35% 渲染比例（~2.86x 超分，最高性能）
 * - BALANCED:    50% 渲染比例（2x 超分，平衡画质与性能）
 * - QUALITY:     65% 渲染比例（~1.54x 超分，偏向画质）
 * - ULTRA:       80% 渲染比例（1.25x 超分，最高画质）
 * - UPSCALED:    100% 渲染比例（在原生分辨率基础上进行超分辨率锐化）
 */
enum class FSR1Preset(
    val displayName: String,
    val renderScale: Float,  // 渲染比例 (0.0-1.0)
    val description: String
) {
    OFF(
        "关闭",
        1.0f,
        "禁用 FSR 超分，使用原生分辨率渲染"
    ),
    PERFORMANCE(
        "性能",
        0.35f,
        "2.86x 超分，最高性能，适合高帧率需求"
    ),
    BALANCED(
        "平衡",
        0.50f,
        "2x 超分，平衡画质与性能"
    ),
    QUALITY(
        "质量",
        0.65f,
        "1.54x 超分，偏向画质"
    ),
    ULTRA(
        "极致",
        0.80f,
        "1.25x 超分，最高画质"
    ),
    UPSCALED(
        "超分",
        1.0f,
        "原生分辨率 + 超分辨率锐化"
    );

    companion object {
        /** 从字符串解析预设（用于配置序列化） */
        fun fromString(name: String): FSR1Preset {
            return try {
                valueOf(name.uppercase())
            } catch (e: IllegalArgumentException) {
                OFF
            }
        }

        /** 可用的预设列表（排除 OFF） */
        val ACTIVE_PRESETS = listOf(PERFORMANCE, BALANCED, QUALITY, ULTRA, UPSCALED)
    }
}
