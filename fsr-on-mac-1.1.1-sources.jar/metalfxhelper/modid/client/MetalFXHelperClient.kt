package metalfxhelper.modid.client

import net.fabricmc.api.ClientModInitializer
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents

class MetalFXHelperClient : ClientModInitializer {
	override fun onInitializeClient() {
		println("🎮 MetalFXHelper 客户端已加载！")

		// 从配置文件恢复上次保存的 FSR 档位，并在游戏循环开始后应用
		// （此时 Window 与 surface 已就绪，updateWindowFSRResolution 才能生效）
		FSR1Manager.loadConfig()
		ClientTickEvents.END_CLIENT_TICK.register {
			FSR1Manager.applyPendingPreset()
		}
	}
}